require('dotenv').config();
const http = require('http');
const { Server } = require('socket.io');
const app = require('./app');
const { setupChatSocket } = require('./modules/chat/chat.socket');
const logger = require('./config/logger');

// Importa as configs para garantir conexão ao inicializar
require('./config/database');
require('./config/redis');

const PORT = parseInt(process.env.PORT) || 4000;

// ── HTTP Server ───────────────────────────────────────────────────────────────
const server = http.createServer(app);

// ── Socket.io ────────────────────────────────────────────────────────────────
const io = new Server(server, {
  cors: {
    origin: (process.env.CORS_ORIGINS || 'http://localhost:3000').split(','),
    credentials: true,
    methods: ['GET', 'POST'],
  },
  transports: ['websocket', 'polling'],
  pingTimeout: 60000,
  pingInterval: 25000,
});

// Disponibiliza io para os controllers via req.app.get('io')
app.set('io', io);
setupChatSocket(io);

// ── Inicialização ─────────────────────────────────────────────────────────────
server.listen(PORT, '0.0.0.0', () => {
  logger.info(`🚀 Servidor rodando na porta ${PORT}`);
  logger.info(`📦 Ambiente: ${process.env.NODE_ENV}`);
  logger.info(`🔗 API: http://localhost:${PORT}/api`);
  logger.info(`❤️  Health: http://localhost:${PORT}/api/health`);
});

// ── Graceful Shutdown ─────────────────────────────────────────────────────────
const shutdown = async (signal) => {
  logger.info(`Sinal ${signal} recebido. Encerrando servidor...`);
  server.close(() => {
    logger.info('Servidor HTTP encerrado. Saindo...');
    process.exit(0);
  });
  // Força encerramento após 10s
  setTimeout(() => {
    logger.error('Timeout de encerramento atingido. Forçando saída.');
    process.exit(1);
  }, 10000);
};

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('uncaughtException', (err) => {
  logger.error('Exceção não capturada', { error: err.message, stack: err.stack });
  shutdown('uncaughtException');
});
process.on('unhandledRejection', (reason) => {
  logger.error('Promise rejeitada não tratada', { reason });
});
