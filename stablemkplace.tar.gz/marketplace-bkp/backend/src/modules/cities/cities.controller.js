const { query } = require('../../config/database');

exports.listCities = async (req, res) => {
  try {
    const result = await query('SELECT * FROM cities ORDER BY name ASC');
    return res.json({ success: true, data: result.rows });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Erro ao listar cidades' });
  }
};

exports.createCity = async (req, res) => {
  const { name, state } = req.body;
  try {
    const result = await query(
      'INSERT INTO cities (name, state) VALUES ($1, $2) RETURNING *',
      [name, state]
    );
    return res.status(201).json({ success: true, data: result.rows[0] });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Erro ao cadastrar cidade' });
  }
};

exports.deleteCity = async (req, res) => {
  try {
    await query('DELETE FROM cities WHERE id = $1', [req.params.id]);
    return res.json({ success: true, message: 'Cidade removida com sucesso' });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Erro ao remover cidade' });
  }
};
