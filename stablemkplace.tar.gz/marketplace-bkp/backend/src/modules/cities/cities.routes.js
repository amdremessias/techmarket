const express = require('express');
const router = express.Router();
const citiesController = require('./cities.controller');
const { authenticate, authorize } = require('../../middleware/auth');

router.get('/', citiesController.listCities);

// Admin only for creation/deletion
router.post('/', authenticate, authorize(['admin']), citiesController.createCity);
router.delete('/:id', authenticate, authorize(['admin']), citiesController.deleteCity);

module.exports = router;
