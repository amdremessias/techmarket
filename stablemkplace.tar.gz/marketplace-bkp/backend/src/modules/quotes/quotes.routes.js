const express = require('express');
const router = express.Router();
const { body, param, query } = require('express-validator');
const { authenticate, authorize } = require('../../middleware/auth');
const controller = require('./quotes.controller');

// Todas as rotas requerem autenticação
router.use(authenticate);

router.get('/', controller.listQuotes);
router.post('/', [
  body('category_id').isUUID().withMessage('Categoria inválida'),
  body('description').isLength({ min: 10, max: 1000 }).withMessage('Descrição deve ter entre 10 e 1000 caracteres'),
  body('latitude').isFloat({ min: -90, max: 90 }).withMessage('Latitude inválida'),
  body('longitude').isFloat({ min: -180, max: 180 }).withMessage('Longitude inválida'),
], authorize(['client']), controller.createQuote);
router.get('/:id', param('id').isUUID(), controller.getQuote);
router.patch('/:id/status', [
  body('status').isIn(controller.QUOTE_STATUSES).withMessage('Status inválido'),
  body('proposed_value').optional().isFloat({ min: 0 }).withMessage('Valor proposto deve ser positivo'),
  body('provider_id').optional().isUUID().withMessage('provider_id deve ser um UUID válido')
], authenticate, controller.updateStatus);

module.exports = router;
