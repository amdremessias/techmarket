const { v4: uuidv4 } = require('uuid');
const { query } = require('../../config/database');
const { createAuditLog } = require('../../middleware/auditLog');
const logger = require('../../config/logger');

// Status válidos do workflow de orçamento
const QUOTE_STATUSES = [
  'PENDING',         // Criado, aguardando pagamento da custódia
  'PAID',            // Taxa de custódia paga
  'MATCHED',         // Prestadores encontrados
  'QUOTED',          // Prestador enviou proposta
  'ACCEPTED',        // Cliente aceitou a proposta
  'IN_PROGRESS',     // Serviço em andamento
  'OTP_PENDING',     // Aguardando confirmação OTP do cliente
  'COMPLETED',       // Concluído com OTP válido
  'CANCELLED',       // Cancelado
  'DISPUTED',        // Em disputa
];

// Transições de status permitidas
const ALLOWED_TRANSITIONS = {
  PENDING: ['PAID', 'CANCELLED'],
  PAID: ['MATCHED', 'CANCELLED'],
  MATCHED: ['QUOTED', 'CANCELLED'],
  QUOTED: ['ACCEPTED', 'CANCELLED'],
  ACCEPTED: ['IN_PROGRESS', 'CANCELLED'],
  IN_PROGRESS: ['OTP_PENDING'],
  OTP_PENDING: ['COMPLETED', 'DISPUTED'],
  COMPLETED: [],
  CANCELLED: [],
  DISPUTED: ['COMPLETED', 'CANCELLED'],
};

// ── CRIAR ORÇAMENTO ───────────────────────────────────────────────────────────
exports.createQuote = async (req, res) => {
  const { category_id, description, latitude, longitude, address } = req.body;

  try {
    const id = uuidv4();
    // Use valores padrão se localização não for fornecida
    const lat = latitude || -23.55052; // São Paulo como default MVP
    const lon = longitude || -46.633309;

    const result = await query(
      `INSERT INTO quotes 
        (id, client_id, category_id, description, address, location, status)
       VALUES 
        ($1, $2, $3, $4, $5, ST_SetSRID(ST_MakePoint($7, $6), 4326), 'PENDING')
       RETURNING id, status, created_at`,
      [id, req.user.id, category_id, description, address || null, lat, lon]
    );

    const quote = result.rows[0];

    await query(
      `INSERT INTO quote_status_log (quote_id, old_status, new_status, changed_by) VALUES ($1, NULL, 'PENDING', $2)`,
      [quote.id, req.user.id]
    );

    await createAuditLog({ userId: req.user.id, action: 'QUOTE_CREATED', entity: 'quotes', entityId: quote.id });

    return res.status(201).json({ success: true, data: quote });
  } catch (err) {
    logger.error('Erro ao criar orçamento', { error: err.message });
    return res.status(500).json({ success: false, message: 'Erro ao criar orçamento' });
  }
};

// ── LISTAR ORÇAMENTOS ────────────────────────────────────────────────────────
exports.listQuotes = async (req, res) => {
  const { status, page = 1, limit = 10, type } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);

  try {
    let whereClause = '';
    let params = [];

    if (req.user.role === 'admin') {
      // Admins veem tudo
      whereClause = status ? 'WHERE q.status = $1' : '';
      params = status ? [status, parseInt(limit), offset] : [parseInt(limit), offset];
    } else if (type === 'available' && req.user.role === 'provider') {
      whereClause = "WHERE q.provider_id IS NULL AND q.status IN ('PENDING', 'PAID')";
      params = [parseInt(limit), offset];
    } else {
      whereClause = req.user.role === 'client'
        ? 'WHERE q.client_id = $1'
        : 'WHERE q.provider_id = $1';
      params = [req.user.id, parseInt(limit), offset];

      if (status && QUOTE_STATUSES.includes(status)) {
        whereClause += ` AND q.status = $${params.length + 1}`;
        params.splice(1, 0, status);
        params[1] = status;
      }
    }

    const result = await query(
      `SELECT 
        q.id, q.status, q.description, q.address, q.proposed_value, q.created_at, q.updated_at,
        sc.name AS category_name, sc.icon AS category_icon,
        c.name AS client_name, c.email AS client_email,
        p.name AS provider_name, p.phone AS provider_phone,
        ST_AsGeoJSON(q.location)::json AS location
       FROM quotes q
       JOIN service_categories sc ON sc.id = q.category_id
       JOIN users c ON c.id = q.client_id
       LEFT JOIN users p ON p.id = q.provider_id
       ${whereClause}
       ORDER BY q.created_at DESC
       LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    );

    return res.json({ success: true, data: result.rows });
  } catch (err) {
    logger.error('Erro ao listar orçamentos', { error: err.message });
    return res.status(500).json({ success: false, message: 'Erro ao listar orçamentos' });
  }
};

// ── BUSCAR ORÇAMENTO POR ID ───────────────────────────────────────────────────
exports.getQuote = async (req, res) => {
  try {
    const isAdmin = req.user.role === 'admin';
    const accessFilter = isAdmin 
      ? 'WHERE q.id = $1' 
      : 'WHERE q.id = $1 AND (q.client_id = $2 OR q.provider_id = $2)';
    const params = isAdmin ? [req.params.id] : [req.params.id, req.user.id];

    const result = await query(
      `SELECT 
        q.*,
        sc.name AS category_name,
        c.name AS client_name, c.email AS client_email,
        p.name AS provider_name, p.phone AS provider_phone,
        ST_AsGeoJSON(q.location)::json AS location
       FROM quotes q
       JOIN service_categories sc ON sc.id = q.category_id
       JOIN users c ON c.id = q.client_id
       LEFT JOIN users p ON p.id = q.provider_id
       ${accessFilter}`,
      params
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Orçamento não encontrado' });
    }
    return res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Erro ao buscar orçamento' });
  }
};

  // ── ATUALIZAR STATUS DO ORÇAMENTO ─────────────────────────────────────────────
  exports.updateStatus = async (req, res) => {
    const { status, proposed_value, provider_id } = req.body;
    const quoteId = req.params.id;

    try {
      const current = await query('SELECT * FROM quotes WHERE id = $1', [quoteId]);
      if (current.rows.length === 0) {
        return res.status(404).json({ success: false, message: 'Orçamento não encontrado' });
      }

      const quote = current.rows[0];
      const currentStatus = quote.status;

      // Valida transição
      if (!ALLOWED_TRANSITIONS[currentStatus]?.includes(status)) {
        return res.status(400).json({
          success: false,
          message: `Transição inválida: ${currentStatus} → ${status}`,
          allowed: ALLOWED_TRANSITIONS[currentStatus],
        });
      }

      // Controle de acesso por role
      const userRole = req.user.role;
      if (userRole === 'client') {
        // Cliente só pode mudar para CANCELLED ou aceitar (se for provider?)
        const clientAllowed = ['CANCELLED'];
        if (!clientAllowed.includes(status)) {
          return res.status(403).json({ success: false, message: 'Cliente não tem permissão para esta transição' });
        }
        // Cliente não pode mudar provider_id nem proposed_value
        if (provider_id || proposed_value) {
          return res.status(403).json({ success: false, message: 'Cliente não pode alterar provider ou valor proposto' });
        }
      } else if (userRole === 'provider') {
        // Provider só pode mudar quando for o responsável
        if (quote.provider_id && quote.provider_id !== req.user.id) {
          return res.status(403).json({ success: false, message: 'Provider não autorizado a atualizar este orçamento' });
        }
        // Provider pode definir provider_id se ainda não existir
        if (provider_id && quote.provider_id && quote.provider_id !== provider_id) {
          return res.status(403).json({ success: false, message: 'Não é permitido mudar provider_id de um orçamento já atribuído' });
        }
      } else if (userRole !== 'admin') {
        return res.status(403).json({ success: false, message: 'Função não reconhecida para atualização de status' });
      }

      const updateFields = ['status = $2', 'updated_at = NOW()'];
      const params = [quoteId, status];

      if (proposed_value) { updateFields.push(`proposed_value = $${params.length + 1}`); params.push(proposed_value); }
      if (provider_id) { updateFields.push(`provider_id = $${params.length + 1}`); params.push(provider_id); }

      await query(`UPDATE quotes SET ${updateFields.join(', ')} WHERE id = $1`, params);

      // Log da mudança de status
      await query(
        `INSERT INTO quote_status_log (quote_id, old_status, new_status, changed_by) VALUES ($1, $2, $3, $4)`,
        [quoteId, currentStatus, status, req.user.id]
      );

      await createAuditLog({
        userId: req.user.id,
        action: 'QUOTE_STATUS_CHANGED',
        entity: 'quotes',
        entityId: quoteId,
        oldValue: { status: currentStatus },
        newValue: { status },
        ip: req.ip,
      });

      return res.json({ success: true, message: `Status atualizado para ${status}` });
    } catch (err) {
      logger.error('Erro ao atualizar status', { error: err.message });
      return res.status(500).json({ success: false, message: 'Erro ao atualizar status do orçamento' });
    }
}
module.exports.QUOTE_STATUSES = QUOTE_STATUSES;
module.exports.ALLOWED_TRANSITIONS = ALLOWED_TRANSITIONS;
