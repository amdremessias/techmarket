const express = require('express');
const router = express.Router();
const { authenticate } = require('../../middleware/auth');
const controller = require('./payments.controller');

// Webhook sem autenticação (chamado pelo MP)
router.post('/webhook', express.raw({ type: 'application/json' }), controller.webhook);

router.use(authenticate);
router.post('/quotes/:quoteId/custody', controller.createCustodyPayment);
router.get('/quotes/:quoteId/status', controller.getPaymentStatus);

module.exports = router;
