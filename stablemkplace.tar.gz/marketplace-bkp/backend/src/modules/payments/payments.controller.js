const { MercadoPagoConfig, Preference, Payment } = require('mercadopago');
const { v4: uuidv4 } = require('uuid');
const { query } = require('../../config/database');
const { createAuditLog } = require('../../middleware/auditLog');
const logger = require('../../config/logger');

// Inicializa Mercado Pago
const mpClient = new MercadoPagoConfig({
  accessToken: process.env.MP_ACCESS_TOKEN,
  options: { timeout: 5000 },
});

const preferenceClient = new Preference(mpClient);
const paymentClient = new Payment(mpClient);

// ── CRIAR PREFERÊNCIA DE PAGAMENTO (Taxa de Custódia R$100) ──────────────────
exports.createCustodyPayment = async (req, res) => {
  const { quoteId } = req.params;

  try {
    // Verifica que o quote pertence ao cliente e está PENDING
    const quoteResult = await query(
      `SELECT q.*, sc.name AS category_name
       FROM quotes q
       JOIN service_categories sc ON sc.id = q.category_id
       WHERE q.id = $1 AND q.client_id = $2 AND q.status = 'PENDING'`,
      [quoteId, req.user.id]
    );

    if (quoteResult.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Orçamento não encontrado ou já pago' });
    }

    const quote = quoteResult.rows[0];
    const custodyAmount = parseFloat(process.env.CUSTODY_AMOUNT) || 100;

    // Cria preferência no Mercado Pago
    const preference = await preferenceClient.create({
      body: {
        items: [
          {
            id: quoteId,
            title: `Taxa de Custódia — ${quote.category_name}`,
            description: `Orçamento #${quoteId.substring(0, 8).toUpperCase()} — ${quote.description?.substring(0, 100) || ''}`,
            quantity: 1,
            unit_price: custodyAmount,
            currency_id: 'BRL',
          },
        ],
        payer: {
          email: req.user.email,
          name: req.user.name,
        },
        external_reference: quoteId,
        notification_url: `${process.env.API_URL}/api/payments/webhook`,
        back_urls: {
          success: `${process.env.FRONTEND_URL}/dashboard/client?payment=success&quote=${quoteId}`,
          failure: `${process.env.FRONTEND_URL}/dashboard/client?payment=failure&quote=${quoteId}`,
          pending: `${process.env.FRONTEND_URL}/dashboard/client?payment=pending&quote=${quoteId}`,
        },
        auto_return: 'approved',
        statement_descriptor: 'MARKETPLACE SERVICOS',
        expires: true,
        expiration_date_from: new Date().toISOString(),
        expiration_date_to: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24h
      },
    });

    await createAuditLog({
      userId: req.user.id,
      action: 'PAYMENT_PREFERENCE_CREATED',
      entity: 'quotes',
      entityId: quoteId,
      newValue: { preferenceId: preference.id, amount: custodyAmount },
      ip: req.ip,
    });

    return res.json({
      success: true,
      data: {
        preference_id: preference.id,
        init_point: preference.init_point,
        sandbox_init_point: preference.sandbox_init_point,
        amount: custodyAmount,
      },
    });
  } catch (err) {
    logger.error('Erro ao criar preferência de pagamento', { error: err.message, quoteId });
    return res.status(500).json({ success: false, message: 'Erro ao iniciar pagamento' });
  }
};

// ── WEBHOOK DO MERCADO PAGO ───────────────────────────────────────────────────
exports.webhook = async (req, res) => {
  const { type, data } = req.body;

  // Confirma autenticidade do webhook via header signature
  // (Em produção, validar HMAC MP-Signature)
  logger.info('Webhook MP recebido', { type, dataId: data?.id });

  if (type === 'payment') {
    try {
      const payment = await paymentClient.get({ id: data.id });

      if (payment.status === 'approved') {
        const quoteId = payment.external_reference;

        await query(
          `UPDATE quotes SET status = 'PAID', payment_id = $1, updated_at = NOW() WHERE id = $2 AND status = 'PENDING'`,
          [String(payment.id), quoteId]
        );

        await query(
          `INSERT INTO quote_status_log (quote_id, old_status, new_status, changed_by) 
           SELECT $1, 'PENDING', 'PAID', client_id FROM quotes WHERE id = $1`,
          [quoteId]
        );

        await createAuditLog({
          userId: null,
          action: 'PAYMENT_APPROVED',
          entity: 'quotes',
          entityId: quoteId,
          newValue: { paymentId: payment.id, status: payment.status },
        });

        logger.info('Pagamento aprovado, quote atualizado', { quoteId, paymentId: payment.id });
      }
    } catch (err) {
      logger.error('Erro ao processar webhook MP', { error: err.message });
    }
  }

  // Sempre retorna 200 para o MP não retentar
  return res.sendStatus(200);
};

// ── VERIFICAR STATUS DE PAGAMENTO ─────────────────────────────────────────────
exports.getPaymentStatus = async (req, res) => {
  const { quoteId } = req.params;

  try {
    const result = await query(
      `SELECT status, payment_id, updated_at FROM quotes WHERE id = $1 AND client_id = $2`,
      [quoteId, req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Orçamento não encontrado' });
    }

    return res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Erro ao verificar pagamento' });
  }
};
