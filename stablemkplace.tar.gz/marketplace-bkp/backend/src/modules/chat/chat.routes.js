const express = require('express');
const router = express.Router();
const { body, param } = require('express-validator');
const { authenticate, authorize } = require('../../middleware/auth');
const controller = require('./chat.controller');

router.use(authenticate);

router.get('/quotes/:quoteId/messages', param('quoteId').isUUID(), controller.getMessages);
router.post('/quotes/:quoteId/messages', [
  param('quoteId').isUUID(),
  body('content').isLength({ min: 1, max: 2000 }).withMessage('Mensagem inválida'),
], controller.sendMessage);

module.exports = router;
