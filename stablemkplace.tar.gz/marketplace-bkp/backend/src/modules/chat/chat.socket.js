const jwt = require('jsonwebtoken');
const logger = require('../../config/logger');

/**
 * Configura o servidor Socket.io para o chat em tempo real
 * @param {import('socket.io').Server} io
 */
const setupChatSocket = (io) => {
  // Middleware de autenticação para Socket.io
  io.use((socket, next) => {
    const token = socket.handshake.auth?.token || socket.handshake.headers?.authorization?.split(' ')[1];
    if (!token) {
      return next(new Error('Token de autenticação não fornecido'));
    }
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      socket.userId = decoded.userId;
      socket.userRole = decoded.role;
      next();
    } catch {
      next(new Error('Token inválido'));
    }
  });

  io.on('connection', (socket) => {
    logger.info('Socket conectado', { userId: socket.userId, socketId: socket.id });

    // Entrar na room de um quote específico
    socket.on('join_quote', (quoteId) => {
      socket.join(`quote:${quoteId}`);
      logger.debug('Usuário entrou na room', { userId: socket.userId, quoteId });
      socket.to(`quote:${quoteId}`).emit('user_joined', {
        userId: socket.userId,
        timestamp: new Date().toISOString(),
      });
    });

    // Sair da room
    socket.on('leave_quote', (quoteId) => {
      socket.leave(`quote:${quoteId}`);
    });

    // Indicador de digitação
    socket.on('typing', (quoteId) => {
      socket.to(`quote:${quoteId}`).emit('user_typing', {
        userId: socket.userId,
        timestamp: new Date().toISOString(),
      });
    });

    socket.on('stop_typing', (quoteId) => {
      socket.to(`quote:${quoteId}`).emit('user_stop_typing', { userId: socket.userId });
    });

    socket.on('disconnect', (reason) => {
      logger.info('Socket desconectado', { userId: socket.userId, reason });
    });

    socket.on('error', (err) => {
      logger.error('Erro no socket', { userId: socket.userId, error: err.message });
    });
  });
};

module.exports = { setupChatSocket };
