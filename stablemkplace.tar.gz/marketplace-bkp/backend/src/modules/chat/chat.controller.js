const { query } = require('../../config/database');
const logger = require('../../config/logger');

// ── ENVIAR MENSAGEM ───────────────────────────────────────────────────────────
exports.sendMessage = async (req, res) => {
  const { quoteId } = req.params;
  const { content } = req.body;

  if (!content || content.trim().length === 0) {
    return res.status(400).json({ success: false, message: 'Mensagem não pode ser vazia' });
  }

  try {
    // Verifica que o usuário é parte do quote
    const quoteResult = await query(
      `SELECT id FROM quotes WHERE id = $1 AND (client_id = $2 OR provider_id = $2) AND status NOT IN ('CANCELLED', 'COMPLETED')`,
      [quoteId, req.user.id]
    );

    if (quoteResult.rows.length === 0) {
      return res.status(403).json({ success: false, message: 'Acesso negado a este chat' });
    }

    const result = await query(
      `INSERT INTO messages (quote_id, sender_id, content) VALUES ($1, $2, $3) RETURNING *`,
      [quoteId, req.user.id, content.trim()]
    );

    const message = {
      ...result.rows[0],
      sender_name: req.user.name,
      sender_role: req.user.role,
    };

    // Emite via Socket.io para a room do quote (se disponível)
    const io = req.app.get('io');
    if (io) {
      io.to(`quote:${quoteId}`).emit('new_message', message);
    }

    return res.status(201).json({ success: true, data: message });
  } catch (err) {
    logger.error('Erro ao enviar mensagem', { error: err.message });
    return res.status(500).json({ success: false, message: 'Erro ao enviar mensagem' });
  }
};

// ── LISTAR MENSAGENS DO CHAT ──────────────────────────────────────────────────
exports.getMessages = async (req, res) => {
  const { quoteId } = req.params;
  const { before, limit = 50 } = req.query;

  try {
    // Verifica acesso
    const access = await query(
      `SELECT id FROM quotes WHERE id = $1 AND (client_id = $2 OR provider_id = $2)`,
      [quoteId, req.user.id]
    );
    if (access.rows.length === 0) {
      return res.status(403).json({ success: false, message: 'Acesso negado' });
    }

    let sql = `
      SELECT m.id, m.content, m.created_at, m.sender_id,
             u.name AS sender_name, u.role AS sender_role
      FROM messages m
      JOIN users u ON u.id = m.sender_id
      WHERE m.quote_id = $1
    `;
    const params = [quoteId];

    if (before) {
      sql += ` AND m.created_at < $${params.length + 1}`;
      params.push(before);
    }

    sql += ` ORDER BY m.created_at DESC LIMIT $${params.length + 1}`;
    params.push(parseInt(limit));

    const result = await query(sql, params);
    return res.json({ success: true, data: result.rows.reverse() });
  } catch (err) {
    logger.error('Erro ao buscar mensagens', { error: err.message });
    return res.status(500).json({ success: false, message: 'Erro ao buscar mensagens' });
  }
};
