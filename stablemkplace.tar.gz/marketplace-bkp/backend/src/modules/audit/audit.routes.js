const express = require('express');
const router = express.Router();
const { authenticate, authorize } = require('../../middleware/auth');
const { query: dbQuery } = require('../../config/database');

router.use(authenticate, authorize(['admin']));

router.get('/', async (req, res) => {
  const { entity, userId, limit = 50, offset = 0 } = req.query;
  try {
    let sql = `
      SELECT al.*, u.name AS user_name, u.email AS user_email
      FROM audit_logs al
      LEFT JOIN users u ON u.id = al.user_id
      WHERE 1=1
    `;
    const params = [];
    if (entity) { sql += ` AND al.entity = $${params.length + 1}`; params.push(entity); }
    if (userId) { sql += ` AND al.user_id = $${params.length + 1}`; params.push(userId); }
    sql += ` ORDER BY al.created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(parseInt(limit), parseInt(offset));
    const result = await dbQuery(sql, params);
    return res.json({ success: true, data: result.rows });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Erro ao buscar audit logs' });
  }
});

module.exports = router;
