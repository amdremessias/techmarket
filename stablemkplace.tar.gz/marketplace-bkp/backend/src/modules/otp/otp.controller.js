const { v4: uuidv4 } = require('uuid');
const { query } = require('../../config/database');
const { createAuditLog } = require('../../middleware/auditLog');
const { sendOTPEmail } = require('../../config/mailer');
const logger = require('../../config/logger');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

/**
 * Gera um OTP de 6 dígitos aleatório
 */
const generateOTP = () => crypto.randomInt(100000, 999999).toString();

// ── GERAR OTP (chamado pelo prestador ao concluir o serviço) ──────────────────
exports.generateOTP = async (req, res) => {
  const { quoteId } = req.params;

  try {
    // Verifica que o quote está no status correto e pertence ao prestador
    const quoteResult = await query(
      `SELECT q.*, c.email AS client_email, c.name AS client_name
       FROM quotes q
       JOIN users c ON c.id = q.client_id
       WHERE q.id = $1 AND q.provider_id = $2 AND q.status = 'IN_PROGRESS'`,
      [quoteId, req.user.id]
    );

    if (quoteResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Orçamento não encontrado ou não está em andamento',
      });
    }

    const quote = quoteResult.rows[0];

    // Invalida OTP anterior se existir
    await query('DELETE FROM otp_tokens WHERE quote_id = $1', [quoteId]);

    // Gera novo OTP
    const otp = generateOTP();
    const expiresAt = new Date(Date.now() + (parseInt(process.env.OTP_EXPIRES_MINUTES) || 30) * 60000);
    const tokenHash = await bcrypt.hash(otp, 10);
    const tokenId = uuidv4();

    await query(
      `INSERT INTO otp_tokens (id, quote_id, token_hash, expires_at) VALUES ($1, $2, $3, $4)`,
      [tokenId, quoteId, tokenHash, expiresAt]
    );

    // Atualiza status do quote para OTP_PENDING
    await query(
      `UPDATE quotes SET status = 'OTP_PENDING', updated_at = NOW() WHERE id = $1`,
      [quoteId]
    );
    await query(
      `INSERT INTO quote_status_log (quote_id, old_status, new_status, changed_by) VALUES ($1, 'IN_PROGRESS', 'OTP_PENDING', $2)`,
      [quoteId, req.user.id]
    );

    // Envia OTP por e-mail ao cliente
    await sendOTPEmail({
      to: quote.client_email,
      name: quote.client_name,
      otp,
      quoteId,
    });

    await createAuditLog({
      userId: req.user.id,
      action: 'OTP_GENERATED',
      entity: 'otp_tokens',
      entityId: tokenId,
      ip: req.ip,
    });

    logger.info('OTP gerado e enviado', { quoteId, tokenId });

    return res.json({
      success: true,
      message: `Código OTP enviado para ${quote.client_email}. Válido por ${process.env.OTP_EXPIRES_MINUTES || 30} minutos.`,
    });
  } catch (err) {
    logger.error('Erro ao gerar OTP', { error: err.message, quoteId });
    return res.status(500).json({ success: false, message: 'Erro ao gerar código OTP' });
  }
};

// ── VALIDAR OTP (chamado pelo cliente para confirmar conclusão) ────────────────
exports.validateOTP = async (req, res) => {
  const { quoteId } = req.params;
  const { otp } = req.body;

  if (!otp || otp.length !== 6) {
    return res.status(400).json({ success: false, message: 'Código OTP deve ter 6 dígitos' });
  }

  try {
    // Busca quote (deve pertencer ao cliente logado e estar no status OTP_PENDING)
    const quoteResult = await query(
      `SELECT * FROM quotes WHERE id = $1 AND client_id = $2 AND status = 'OTP_PENDING'`,
      [quoteId, req.user.id]
    );

    if (quoteResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Orçamento não encontrado ou não está aguardando confirmação OTP',
      });
    }

    // Busca token OTP
    const tokenResult = await query(
      `SELECT * FROM otp_tokens WHERE quote_id = $1 AND expires_at > NOW()`,
      [quoteId]
    );

    if (tokenResult.rows.length === 0) {
      return res.status(400).json({ success: false, message: 'Código OTP expirado. Solicite um novo.' });
    }

    const token = tokenResult.rows[0];

    // Verifica tentativas
    const maxAttempts = parseInt(process.env.OTP_MAX_ATTEMPTS) || 3;
    if (token.attempts >= maxAttempts) {
      await query('DELETE FROM otp_tokens WHERE quote_id = $1', [quoteId]);
      return res.status(400).json({ success: false, message: 'Número máximo de tentativas excedido. Solicite um novo código.' });
    }

    // Incrementa tentativas
    await query('UPDATE otp_tokens SET attempts = attempts + 1 WHERE id = $1', [token.id]);

    // Verifica OTP
    const isValid = await bcrypt.compare(otp, token.token_hash);
    if (!isValid) {
      const remaining = maxAttempts - token.attempts - 1;
      return res.status(400).json({
        success: false,
        message: `Código incorreto. ${remaining} tentativa(s) restante(s).`,
      });
    }

    // OTP válido → conclui o serviço
    await query(
      `UPDATE quotes SET status = 'COMPLETED', completed_at = NOW(), updated_at = NOW() WHERE id = $1`,
      [quoteId]
    );
    await query(
      `INSERT INTO quote_status_log (quote_id, old_status, new_status, changed_by) VALUES ($1, 'OTP_PENDING', 'COMPLETED', $2)`,
      [quoteId, req.user.id]
    );
    await query('DELETE FROM otp_tokens WHERE quote_id = $1', [quoteId]);

    await createAuditLog({
      userId: req.user.id,
      action: 'SERVICE_COMPLETED_VIA_OTP',
      entity: 'quotes',
      entityId: quoteId,
      ip: req.ip,
    });

    logger.info('Serviço concluído via OTP', { quoteId, clientId: req.user.id });

    return res.json({
      success: true,
      message: '✅ Serviço confirmado com sucesso! O pagamento será liberado ao prestador.',
    });
  } catch (err) {
    logger.error('Erro ao validar OTP', { error: err.message, quoteId });
    return res.status(500).json({ success: false, message: 'Erro ao validar código OTP' });
  }
};
