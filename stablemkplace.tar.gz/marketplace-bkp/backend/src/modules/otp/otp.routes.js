const express = require('express');
const router = express.Router();
const { body, param } = require('express-validator');
const { authenticate, authorize } = require('../../middleware/auth');
const controller = require('./otp.controller');

router.use(authenticate);

// Prestador gera OTP ao concluir o serviço
router.post('/quotes/:quoteId/generate', param('quoteId').isUUID(), authorize(['provider']), controller.generateOTP);

// Cliente valida o OTP para confirmar conclusão
router.post('/quotes/:quoteId/validate', [
  param('quoteId').isUUID(),
  body('otp').isLength({ min: 6, max: 6 }).isNumeric().withMessage('OTP deve ser 6 dígitos'),
], authorize(['client']), controller.validateOTP);

module.exports = router;
