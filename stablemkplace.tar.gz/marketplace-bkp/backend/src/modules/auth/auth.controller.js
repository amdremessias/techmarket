const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { query } = require('../../config/database');
const { set, del, get } = require('../../config/redis');
const { sendWelcomeEmail } = require('../../config/mailer');
const { createAuditLog } = require('../../middleware/auditLog');
const logger = require('../../config/logger');

const SALT_ROUNDS = 12;

/**
 * Gera par de tokens JWT (access + refresh)
 */
const generateTokens = (userId, role) => {
  const accessToken = jwt.sign(
    { userId, role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '15m' }
  );
  const refreshToken = jwt.sign(
    { userId, role, type: 'refresh' },
    process.env.JWT_REFRESH_SECRET,
    { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d' }
  );
  return { accessToken, refreshToken };
};

// ── REGISTRO ──────────────────────────────────────────────────────────────────
exports.register = async (req, res) => {
  const { name, email, password, role = 'client', phone, categoryIds = [] } = req.body;

  try {
    // Verifica se e-mail já existe
    const existing = await query('SELECT id FROM users WHERE email = $1', [email.toLowerCase()]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ success: false, message: 'E-mail já cadastrado' });
    }

    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

    const result = await query(
      `INSERT INTO users (id, name, email, password_hash, role, phone, technician_level)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING id, name, email, role, created_at`,
      [uuidv4(), name, email.toLowerCase(), passwordHash, role, phone || null, role === 'provider' ? 'junior' : null]
    );

    const user = result.rows[0];
    if (role === 'provider' && Array.isArray(categoryIds) && categoryIds.length > 0) {
      for (const catId of categoryIds) {
        await query(
          'INSERT INTO provider_categories (user_id, category_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
          [user.id, catId]
        );
      }
    }
    const { accessToken, refreshToken } = generateTokens(user.id, user.role);

    // Armazena refresh token no Redis (TTL: 7 dias)
    await set(`refresh:${user.id}`, refreshToken, parseInt(process.env.REDIS_TTL_SESSION) || 604800);

    await createAuditLog({ userId: user.id, action: 'USER_REGISTERED', entity: 'users', entityId: user.id });

    // Envia e-mail de boas-vindas (não bloqueia a resposta)
    sendWelcomeEmail({ to: user.email, name: user.name }).catch(() => {});

    return res.status(201).json({
      success: true,
      message: 'Conta criada com sucesso',
      data: { user, accessToken, refreshToken },
    });
  } catch (err) {
    logger.error('Erro no registro', { error: err.message });
    return res.status(500).json({ success: false, message: 'Erro interno ao criar conta' });
  }
};

// ── LOGIN ─────────────────────────────────────────────────────────────────────
exports.login = async (req, res) => {
  const { email, password } = req.body;

  try {
    const result = await query(
      'SELECT id, name, email, password_hash, role, is_active FROM users WHERE email = $1',
      [email.toLowerCase()]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ success: false, message: 'Credenciais inválidas' });
    }

    const user = result.rows[0];

    if (!user.is_active) {
      return res.status(401).json({ success: false, message: 'Conta desativada. Entre em contato com o suporte.' });
    }

    const isValid = await bcrypt.compare(password, user.password_hash);
    if (!isValid) {
      await createAuditLog({ userId: user.id, action: 'LOGIN_FAILED', entity: 'users', entityId: user.id, ip: req.ip });
      return res.status(401).json({ success: false, message: 'Credenciais inválidas' });
    }

    const { accessToken, refreshToken } = generateTokens(user.id, user.role);
    await set(`refresh:${user.id}`, refreshToken, parseInt(process.env.REDIS_TTL_SESSION) || 604800);

    await createAuditLog({ userId: user.id, action: 'LOGIN_SUCCESS', entity: 'users', entityId: user.id, ip: req.ip });

    const { password_hash, ...userSafe } = user;
    return res.json({
      success: true,
      data: { user: userSafe, accessToken, refreshToken },
    });
  } catch (err) {
    logger.error('Erro no login', { error: err.message });
    return res.status(500).json({ success: false, message: 'Erro interno de autenticação' });
  }
};

// ── REFRESH TOKEN ─────────────────────────────────────────────────────────────
exports.refreshToken = async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) {
    return res.status(400).json({ success: false, message: 'Refresh token não fornecido' });
  }

  try {
    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    const storedToken = await get(`refresh:${decoded.userId}`);

    if (!storedToken || storedToken !== refreshToken) {
      return res.status(401).json({ success: false, message: 'Refresh token inválido ou expirado' });
    }

    const { accessToken, refreshToken: newRefresh } = generateTokens(decoded.userId, decoded.role);
    await set(`refresh:${decoded.userId}`, newRefresh, parseInt(process.env.REDIS_TTL_SESSION) || 604800);

    return res.json({ success: true, data: { accessToken, refreshToken: newRefresh } });
  } catch (err) {
    return res.status(401).json({ success: false, message: 'Refresh token inválido' });
  }
};

// ── LOGOUT ────────────────────────────────────────────────────────────────────
exports.logout = async (req, res) => {
  try {
    await del(`refresh:${req.user.id}`);
    await createAuditLog({ userId: req.user.id, action: 'LOGOUT', entity: 'users', entityId: req.user.id, ip: req.ip });
    return res.json({ success: true, message: 'Logout realizado com sucesso' });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Erro ao realizar logout' });
  }
};

// ── ME (perfil do usuário logado) ─────────────────────────────────────────────
exports.me = async (req, res) => {
  try {
    const result = await query(
      `SELECT id, name, email, role, phone, plan, is_active, created_at,
              ST_AsGeoJSON(location)::json AS location
       FROM users WHERE id = $1`,
      [req.user.id]
    );
    return res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Erro ao buscar perfil' });
  }
};
