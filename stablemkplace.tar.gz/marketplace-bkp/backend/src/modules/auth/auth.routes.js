const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const { authenticate } = require('../../middleware/auth');
const { authLimiter } = require('../../middleware/security');
const controller = require('./auth.controller');

const validateRegister = [
  body('name').trim().isLength({ min: 2, max: 100 }).withMessage('Nome deve ter entre 2 e 100 caracteres'),
  body('email').isEmail().normalizeEmail().withMessage('E-mail invalido'),
  body('password').isLength({ min: 8 }).withMessage('Senha deve ter no minimo 8 caracteres')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/).withMessage('Senha deve conter maiuscula, minuscula e numero'),
  body('role').optional().isIn(['client', 'provider']).withMessage('Role invalida'),
  body('phone').optional({ checkFalsy: true }).isMobilePhone('pt-BR').withMessage('Telefone invalido'),
  body('categoryIds').optional().isArray().withMessage('Categorias invalidas'),
  body('categoryIds.*').optional().isUUID().withMessage('Categoria invalida'),
];

const validateLogin = [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty(),
];

router.post('/register', authLimiter, validateRegister, controller.register);
router.post('/login', authLimiter, validateLogin, controller.login);
router.post('/refresh', controller.refreshToken);

router.post('/logout', authenticate, controller.logout);
router.get('/me', authenticate, controller.me);

module.exports = router;
