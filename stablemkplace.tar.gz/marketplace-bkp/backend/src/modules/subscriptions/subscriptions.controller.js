const { MercadoPagoConfig, Preference } = require('mercadopago');
const { v4: uuidv4 } = require('uuid');
const { query } = require('../../config/database');
const { createAuditLog } = require('../../middleware/auditLog');
const logger = require('../../config/logger');

const mpClient = new MercadoPagoConfig({ accessToken: process.env.MP_ACCESS_TOKEN });
const preferenceClient = new Preference(mpClient);

const PLANS = {
  FREE: { name: 'Gratuito', price: 0, features: ['5 orçamentos/mês', 'Chat básico'] },
  PREMIUM_PROVIDER: { name: 'Prestador Premium', price: 99.90, features: ['Orçamentos ilimitados', 'Destaque na busca', 'Analytics', 'Prioridade no matching'] },
  PREMIUM_CLIENT: { name: 'Cliente Premium', price: 49.90, features: ['Taxa de custódia reduzida (R$50)', 'Histórico completo', 'Suporte prioritário'] },
};

// ── LISTAR PLANOS ─────────────────────────────────────────────────────────────
exports.listPlans = async (req, res) => {
  return res.json({ success: true, data: PLANS });
};

// ── ASSINAR PLANO ─────────────────────────────────────────────────────────────
exports.subscribe = async (req, res) => {
  const { plan } = req.body;

  if (!PLANS[plan] || plan === 'FREE') {
    return res.status(400).json({ success: false, message: 'Plano inválido' });
  }

  const planInfo = PLANS[plan];

  try {
    const preference = await preferenceClient.create({
      body: {
        items: [
          {
            id: `PLAN_${plan}`,
            title: `Assinatura ${planInfo.name} — Mensal`,
            quantity: 1,
            unit_price: planInfo.price,
            currency_id: 'BRL',
          },
        ],
        payer: { email: req.user.email, name: req.user.name },
        external_reference: `SUB_${req.user.id}_${plan}`,
        notification_url: `${process.env.API_URL}/api/payments/webhook`,
        back_urls: {
          success: `${process.env.FRONTEND_URL}/dashboard?subscription=success`,
          failure: `${process.env.FRONTEND_URL}/dashboard?subscription=failure`,
        },
        auto_return: 'approved',
      },
    });

    await createAuditLog({
      userId: req.user.id,
      action: 'SUBSCRIPTION_INITIATED',
      entity: 'subscriptions',
      entityId: req.user.id,
      newValue: { plan, amount: planInfo.price },
      ip: req.ip,
    });

    return res.json({
      success: true,
      data: {
        preference_id: preference.id,
        init_point: preference.init_point,
        plan,
        price: planInfo.price,
      },
    });
  } catch (err) {
    logger.error('Erro ao criar assinatura', { error: err.message });
    return res.status(500).json({ success: false, message: 'Erro ao processar assinatura' });
  }
};

// ── STATUS DA ASSINATURA ATUAL ────────────────────────────────────────────────
exports.getSubscription = async (req, res) => {
  try {
    const result = await query(
      `SELECT plan, subscription_status, subscription_expires_at FROM users WHERE id = $1`,
      [req.user.id]
    );
    return res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Erro ao buscar assinatura' });
  }
};
