const express = require('express');
const router = express.Router();
const { authenticate } = require('../../middleware/auth');
const controller = require('./subscriptions.controller');

router.get('/plans', controller.listPlans);
router.use(authenticate);
router.post('/subscribe', controller.subscribe);
router.get('/my', controller.getSubscription);

module.exports = router;
