const { query } = require('../../config/database');
const bcrypt = require('bcryptjs');

const VALID_ROLES = ['client', 'provider', 'admin'];
const VALID_LEVELS = ['junior', 'pleno', 'senior', 'especialista'];

exports.listUsers = async (req, res) => {
  try {
    const result = await query(`
      SELECT
        u.id, u.name, u.email, u.role, u.phone, u.plan, u.subscription_status,
        u.is_active, u.email_verified, u.technician_level, u.created_at,
        COALESCE(
          ARRAY(SELECT category_id FROM provider_categories WHERE user_id = u.id),
          ARRAY[]::uuid[]
        ) AS services,
        COALESCE(
          ARRAY(
            SELECT sc.name
            FROM provider_categories pc
            JOIN service_categories sc ON sc.id = pc.category_id
            WHERE pc.user_id = u.id
            ORDER BY sc.name
          ),
          ARRAY[]::varchar[]
        ) AS service_names
      FROM users u
      ORDER BY u.created_at DESC
    `);
    return res.json({ success: true, data: result.rows });
  } catch (err) {
    console.error('listUsers error:', err.message);
    return res.status(500).json({ success: false, message: 'Erro ao listar usuarios' });
  }
};

exports.createUser = async (req, res) => {
  const { name, email, password, role, phone, plan, technicianLevel, categoryIds = [] } = req.body;
  if (!name || !email || !password || !role) {
    return res.status(400).json({ success: false, message: 'Todos os campos sao obrigatorios' });
  }
  if (!VALID_ROLES.includes(role)) {
    return res.status(400).json({ success: false, message: 'Tipo de usuario invalido' });
  }

  try {
    const hash = await bcrypt.hash(password, 12);
    const result = await query(
      `INSERT INTO users (name, email, password_hash, role, phone, plan, technician_level, is_active, email_verified)
       VALUES ($1, $2, $3, $4, $5, COALESCE($6::subscription_plan, 'FREE'::subscription_plan), $7, true, true)
       RETURNING id, name, email, role`,
      [
        name.trim(),
        email.toLowerCase().trim(),
        hash,
        role,
        phone || null,
        plan || null,
        role === 'provider' ? (technicianLevel || 'junior') : null,
      ]
    );

    const user = result.rows[0];
    if (role === 'provider' && Array.isArray(categoryIds)) {
      await replaceProviderCategories(user.id, categoryIds);
    }

    return res.status(201).json({ success: true, data: user });
  } catch (err) {
    if (err.code === '23505') return res.status(400).json({ success: false, message: 'E-mail ja cadastrado' });
    console.error('createUser error:', err.message);
    return res.status(500).json({ success: false, message: 'Erro ao criar usuario' });
  }
};

exports.updateUser = async (req, res) => {
  const { id } = req.params;
  const {
    name,
    email,
    role,
    phone,
    plan,
    subscriptionStatus,
    isActive,
    emailVerified,
    technicianLevel,
    categoryIds,
  } = req.body;

  if (!name || !email || !role) {
    return res.status(400).json({ success: false, message: 'Nome, e-mail e tipo sao obrigatorios' });
  }
  if (!VALID_ROLES.includes(role)) {
    return res.status(400).json({ success: false, message: 'Tipo de usuario invalido' });
  }
  if (role === 'provider' && technicianLevel && !VALID_LEVELS.includes(technicianLevel)) {
    return res.status(400).json({ success: false, message: 'Nivel tecnico invalido' });
  }

  try {
    const result = await query(
      `UPDATE users
       SET name = $1,
           email = $2,
           role = $3::user_role,
           phone = $4,
           plan = COALESCE($5::subscription_plan, plan),
           subscription_status = COALESCE($6::subscription_status, subscription_status),
           is_active = COALESCE($7, is_active),
           email_verified = COALESCE($8, email_verified),
           technician_level = CASE WHEN $3::user_role = 'provider'::user_role THEN COALESCE($9, technician_level, 'junior') ELSE NULL END,
           updated_at = NOW()
       WHERE id = $10
       RETURNING id, name, email, role, phone, plan, subscription_status, is_active, email_verified, technician_level`,
      [
        name.trim(),
        email.toLowerCase().trim(),
        role,
        phone || null,
        plan || null,
        subscriptionStatus || null,
        typeof isActive === 'boolean' ? isActive : null,
        typeof emailVerified === 'boolean' ? emailVerified : null,
        technicianLevel || null,
        id,
      ]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Usuario nao encontrado' });
    }

    if (Array.isArray(categoryIds)) {
      if (role === 'provider') {
        await replaceProviderCategories(id, categoryIds);
      } else {
        await query('DELETE FROM provider_categories WHERE user_id = $1', [id]);
      }
    }

    return res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    if (err.code === '23505') return res.status(400).json({ success: false, message: 'E-mail ja cadastrado' });
    console.error('updateUser error:', err.message);
    return res.status(500).json({ success: false, message: 'Erro ao editar usuario' });
  }
};

exports.toggleActive = async (req, res) => {
  try {
    const user = await query('SELECT is_active FROM users WHERE id = $1', [req.params.id]);
    if (user.rows.length === 0) return res.status(404).json({ success: false, message: 'Usuario nao encontrado' });

    const newStatus = !user.rows[0].is_active;
    await query('UPDATE users SET is_active = $1, updated_at = NOW() WHERE id = $2', [newStatus, req.params.id]);

    return res.json({ success: true, message: `Usuario ${newStatus ? 'ativado' : 'desativado'} com sucesso` });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Erro ao alterar status' });
  }
};

exports.updateProviderServices = async (req, res) => {
  const { categoryIds } = req.body;
  const providerId = req.params.id;

  try {
    const provider = await query('SELECT id, role FROM users WHERE id = $1', [providerId]);
    if (provider.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Tecnico nao encontrado' });
    }
    if (provider.rows[0].role !== 'provider') {
      return res.status(400).json({ success: false, message: 'Categorias so podem ser atribuidas a tecnicos' });
    }

    await replaceProviderCategories(providerId, Array.isArray(categoryIds) ? categoryIds : []);
    return res.json({ success: true, message: 'Categorias do tecnico atualizadas com sucesso' });
  } catch (err) {
    console.error('updateProviderServices error:', err.message);
    return res.status(500).json({ success: false, message: 'Erro ao atualizar categorias do tecnico' });
  }
};

exports.changePassword = async (req, res) => {
  const { id } = req.params;
  const { newPassword } = req.body;

  if (!newPassword || newPassword.length < 8) {
    return res.status(400).json({ success: false, message: 'Senha deve ter no minimo 8 caracteres' });
  }

  try {
    const userRes = await query('SELECT id FROM users WHERE id = $1', [id]);
    if (userRes.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Usuario nao encontrado' });
    }

    const hash = await bcrypt.hash(newPassword, 12);
    await query('UPDATE users SET password_hash = $1, updated_at = NOW() WHERE id = $2', [hash, id]);

    return res.json({ success: true, message: 'Senha alterada com sucesso' });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Erro ao alterar senha' });
  }
};

exports.changeOwnPassword = async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  const userId = req.user.id;

  if (!currentPassword || !newPassword || newPassword.length < 8) {
    return res.status(400).json({ success: false, message: 'Dados invalidos - senha minima 8 caracteres' });
  }

  try {
    const userRes = await query('SELECT password_hash FROM users WHERE id = $1', [userId]);
    if (userRes.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Usuario nao encontrado' });
    }

    const valid = await bcrypt.compare(currentPassword, userRes.rows[0].password_hash);
    if (!valid) {
      return res.status(401).json({ success: false, message: 'Senha atual incorreta' });
    }

    const hash = await bcrypt.hash(newPassword, 12);
    await query('UPDATE users SET password_hash = $1, updated_at = NOW() WHERE id = $2', [hash, userId]);

    return res.json({ success: true, message: 'Senha alterada com sucesso' });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Erro ao alterar senha' });
  }
};

async function replaceProviderCategories(userId, categoryIds) {
  await query('DELETE FROM provider_categories WHERE user_id = $1', [userId]);
  for (const catId of categoryIds) {
    await query(
      'INSERT INTO provider_categories (user_id, category_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
      [userId, catId]
    );
  }
}
