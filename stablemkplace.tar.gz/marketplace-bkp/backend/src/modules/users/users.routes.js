const express = require('express');
const router = express.Router();
const userController = require('./users.controller');
const { authenticate, authorize } = require('../../middleware/auth');

router.use(authenticate);

// Rota para o próprio usuário trocar a própria senha (qualquer role)
router.patch('/me/password', userController.changeOwnPassword);

const adminOnly = authorize(['admin']);
router.use(adminOnly);

router.get('/', userController.listUsers);
router.post('/', userController.createUser);
router.put('/:id', userController.updateUser);
router.patch('/:id/toggle-active', userController.toggleActive);
router.post('/:id/services', userController.updateProviderServices);
// Admin troca senha de qualquer usuário
router.patch('/:id/password', userController.changePassword);

module.exports = router;
