const { query } = require('../../config/database');
const { set, get } = require('../../config/redis');
const { createAuditLog } = require('../../middleware/auditLog');
const logger = require('../../config/logger');

// ── LISTAR PRESTADORES POR PROXIMIDADE (PostGIS) ──────────────────────────────
exports.findNearbyProviders = async (req, res) => {
  const { latitude, longitude, radius_km, category_id } = req.query;

  if (!latitude || !longitude) {
    return res.status(400).json({ success: false, message: 'Latitude e longitude são obrigatórios' });
  }

  const lat = parseFloat(latitude);
  const lng = parseFloat(longitude);
  const radius = parseFloat(radius_km) || parseFloat(process.env.DEFAULT_SEARCH_RADIUS_KM) || 30;
  const limit = parseInt(process.env.MAX_PROVIDERS_PER_MATCH) || 5;

  // Cache key baseada na localização (arredondada para 2 decimais = ~1km)
  const cacheKey = `nearby:${lat.toFixed(2)}:${lng.toFixed(2)}:${radius}:${category_id || 'all'}`;
  
  try {
    // Tenta cache primeiro
    const cached = await get(cacheKey);
    if (cached) {
      return res.json({ success: true, data: cached, cached: true });
    }

    // Query PostGIS: ST_DWithin para busca geográfica eficiente
    let sql = `
      SELECT 
        u.id, u.name, u.phone, u.plan,
        ST_Distance(
          u.location::geography,
          ST_SetSRID(ST_MakePoint($2, $1), 4326)::geography
        ) / 1000 AS distance_km,
        ST_AsGeoJSON(u.location)::json AS location,
        COALESCE(
          (SELECT AVG(r.rating) FROM reviews r WHERE r.provider_id = u.id),
          0
        ) AS avg_rating,
        (SELECT COUNT(*) FROM reviews r WHERE r.provider_id = u.id) AS total_reviews,
        ARRAY_AGG(DISTINCT sc.name) AS categories
      FROM users u
      LEFT JOIN provider_categories pc ON pc.user_id = u.id
      LEFT JOIN service_categories sc ON sc.id = pc.category_id
      WHERE 
        u.role = 'provider'
        AND u.is_active = true
        AND u.location IS NOT NULL
        AND ST_DWithin(
          u.location::geography,
          ST_SetSRID(ST_MakePoint($2, $1), 4326)::geography,
          $3 * 1000  -- converte km para metros
        )
    `;
    const params = [lat, lng, radius];

    if (category_id) {
      sql += ` AND pc.category_id = $4`;
      params.push(category_id);
    }

    sql += `
      GROUP BY u.id, u.name, u.phone, u.plan, u.location
      ORDER BY distance_km ASC
      LIMIT $${params.length + 1}
    `;
    params.push(limit);

    const result = await query(sql, params);
    const providers = result.rows;

    // Armazena no cache por 5 minutos
    await set(cacheKey, providers, parseInt(process.env.REDIS_TTL_LOCATION) || 300);

    return res.json({ success: true, data: providers, cached: false });
  } catch (err) {
    logger.error('Erro no matchmaking geográfico', { error: err.message });
    return res.status(500).json({ success: false, message: 'Erro ao buscar prestadores próximos' });
  }
};

// ── ATUALIZAR LOCALIZAÇÃO DO PRESTADOR ────────────────────────────────────────
exports.updateLocation = async (req, res) => {
  const { latitude, longitude } = req.body;

  if (!latitude || !longitude) {
    return res.status(400).json({ success: false, message: 'Coordenadas inválidas' });
  }

  try {
    await query(
      `UPDATE users 
       SET location = ST_SetSRID(ST_MakePoint($1, $2), 4326), updated_at = NOW()
       WHERE id = $3`,
      [longitude, latitude, req.user.id]
    );

    await createAuditLog({
      userId: req.user.id,
      action: 'LOCATION_UPDATED',
      entity: 'users',
      entityId: req.user.id,
      newValue: { latitude, longitude },
      ip: req.ip,
    });

    return res.json({ success: true, message: 'Localização atualizada com sucesso' });
  } catch (err) {
    logger.error('Erro ao atualizar localização', { error: err.message });
    return res.status(500).json({ success: false, message: 'Erro ao atualizar localização' });
  }
};
