const express = require('express');
const router = express.Router();
const { authenticate, authorize } = require('../../middleware/auth');
const controller = require('./matching.controller');

router.get('/nearby', authenticate, controller.findNearbyProviders);
router.put('/location', authenticate, authorize(['provider']), controller.updateLocation);

module.exports = router;
