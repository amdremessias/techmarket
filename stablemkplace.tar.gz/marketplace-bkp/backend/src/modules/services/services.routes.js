const express = require('express');
const router = express.Router();
const { query: dbQuery } = require('../../config/database');
const { authenticate, authorize } = require('../../middleware/auth');

const slugify = (value) => String(value || '')
  .normalize('NFD')
  .replace(/[\u0300-\u036f]/g, '')
  .toLowerCase()
  .replace(/[^a-z0-9]+/g, '-')
  .replace(/(^-|-$)/g, '');

router.get('/', async (req, res) => {
  try {
    const result = await dbQuery('SELECT * FROM service_categories ORDER BY name ASC');
    return res.json({ success: true, data: result.rows });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Erro ao buscar categorias' });
  }
});

router.post('/', authenticate, authorize(['admin']), async (req, res) => {
  const { name, icon, description } = req.body;
  if (!name || name.trim().length < 2) {
    return res.status(400).json({ success: false, message: 'Nome da categoria obrigatorio' });
  }

  const baseSlug = slugify(name);
  try {
    let slug = baseSlug;
    let suffix = 2;
    while (true) {
      const exists = await dbQuery('SELECT id FROM service_categories WHERE slug = $1', [slug]);
      if (exists.rows.length === 0) break;
      slug = `${baseSlug}-${suffix}`;
      suffix += 1;
    }

    const result = await dbQuery(
      `INSERT INTO service_categories (name, slug, description, icon, is_active)
       VALUES ($1, $2, $3, $4, true)
       RETURNING *`,
      [name.trim(), slug, description || null, icon || 'tool']
    );
    return res.status(201).json({ success: true, data: result.rows[0] });
  } catch (err) {
    if (err.code === '23505') {
      return res.status(409).json({ success: false, message: 'Categoria ja cadastrada' });
    }
    return res.status(500).json({ success: false, message: 'Erro ao criar categoria' });
  }
});

router.put('/:id', authenticate, authorize(['admin']), async (req, res) => {
  const { name, icon, description, is_active } = req.body;
  if (!name || name.trim().length < 2) {
    return res.status(400).json({ success: false, message: 'Nome da categoria obrigatorio' });
  }

  try {
    const result = await dbQuery(
      `UPDATE service_categories
       SET name = $1,
           description = $2,
           icon = $3,
           is_active = COALESCE($4, is_active)
       WHERE id = $5
       RETURNING *`,
      [name.trim(), description || null, icon || 'tool', typeof is_active === 'boolean' ? is_active : null, req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Categoria nao encontrada' });
    }
    return res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Erro ao editar categoria' });
  }
});

router.patch('/:id/toggle', authenticate, authorize(['admin']), async (req, res) => {
  try {
    await dbQuery('UPDATE service_categories SET is_active = NOT is_active WHERE id = $1', [req.params.id]);
    return res.json({ success: true, message: 'Status atualizado' });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Erro ao atualizar categoria' });
  }
});

module.exports = router;
