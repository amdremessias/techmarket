const { query } = require('../config/database');
const logger = require('../config/logger');

/**
 * Registra uma ação de auditoria no banco de dados.
 * Deve ser chamado em operações sensíveis (mudança de status, pagamentos, etc.)
 *
 * @param {Object} params
 * @param {string} params.userId - ID do usuário que realizou a ação
 * @param {string} params.action - Descrição da ação (ex: 'QUOTE_STATUS_CHANGED')
 * @param {string} params.entity - Entidade afetada (ex: 'quotes', 'users')
 * @param {string} params.entityId - ID da entidade afetada
 * @param {Object} [params.oldValue] - Valor anterior (opcional)
 * @param {Object} [params.newValue] - Valor novo (opcional)
 * @param {string} [params.ip] - IP do cliente
 */
const createAuditLog = async ({ userId, action, entity, entityId, oldValue = null, newValue = null, ip = null }) => {
  try {
    await query(
      `INSERT INTO audit_logs (user_id, action, entity, entity_id, old_value, new_value, ip_address)
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      [
        userId,
        action,
        entity,
        entityId,
        oldValue ? JSON.stringify(oldValue) : null,
        newValue ? JSON.stringify(newValue) : null,
        ip,
      ]
    );
  } catch (err) {
    // Não deixa o erro de audit log derrubar a operação principal
    logger.error('Falha ao gravar audit log', { userId, action, entity, entityId, error: err.message });
  }
};

/**
 * Middleware Express que registra automaticamente o audit log após a resposta
 * (para rotas sensíveis)
 */
const auditMiddleware = (action, entity) => {
  return async (req, res, next) => {
    const originalJson = res.json.bind(res);
    res.json = async (data) => {
      if (res.statusCode < 400 && req.user) {
        await createAuditLog({
          userId: req.user.id,
          action,
          entity,
          entityId: req.params.id || (data && data.data && data.data.id) || null,
          ip: req.ip,
        });
      }
      return originalJson(data);
    };
    next();
  };
};

module.exports = { createAuditLog, auditMiddleware };
