const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const xss = require('xss');
const logger = require('../config/logger');

// ── CORS ─────────────────────────────────────────────────────────────────────
const allowedOrigins = [
  'http://localhost:3000',
  'http://192.168.5.67',
  'http://192.168.5.67:3000'
].concat((process.env.CORS_ORIGINS || '').split(',').filter(origin => origin.trim() !== ''));

const corsOptions = {
  origin: (origin, callback) => {
    // Permite requisições sem origin (curl, Postman, etc.) em desenvolvimento
    if (!origin && process.env.NODE_ENV !== 'production') {
      return callback(null, true);
    }
    if (allowedOrigins.includes(origin)) {
      return callback(null, true);
    }
    logger.warn('Requisição CORS bloqueada', { origin });
    callback(new Error(`CORS: Origin '${origin}' não permitida`));
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Request-ID'],
  exposedHeaders: ['X-Total-Count', 'X-Page'],
};

// ── RATE LIMITING ─────────────────────────────────────────────────────────────
// Limite geral
const generalLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
  message: { success: false, message: 'Muitas requisições. Tente novamente em instantes.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// Limite rigoroso para auth (previne brute force — OWASP A07)
const authLimiter = rateLimit({
  windowMs: 5 * 60 * 1000, // 5 minutos
  max: 30, // 30 tentativas
  message: { success: false, message: 'Muitas tentativas de login. Bloqueado por 5 minutos.' },
  skipSuccessfulRequests: true,
});

// ── XSS SANITIZER ─────────────────────────────────────────────────────────────
const sanitizeBody = (req, res, next) => {
  if (req.body && typeof req.body === 'object') {
    const sanitize = (obj) => {
      Object.keys(obj).forEach((key) => {
        if (typeof obj[key] === 'string') {
          obj[key] = xss(obj[key]);
        } else if (typeof obj[key] === 'object' && obj[key] !== null) {
          sanitize(obj[key]);
        }
      });
    };
    sanitize(req.body);
  }
  next();
};

// ── HELMET (Security Headers) ─────────────────────────────────────────────────
const helmetConfig = helmet({
  contentSecurityPolicy: false, // Desabilitado pois Nginx cuida disso
  crossOriginEmbedderPolicy: false,
});

// ── REQUEST ID ────────────────────────────────────────────────────────────────
const { v4: uuidv4 } = require('uuid');
const requestId = (req, res, next) => {
  req.id = req.headers['x-request-id'] || uuidv4();
  res.setHeader('X-Request-ID', req.id);
  next();
};

module.exports = { corsOptions, generalLimiter, authLimiter, sanitizeBody, helmetConfig, requestId };
