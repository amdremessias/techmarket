require('dotenv').config();
const express = require('express');
const morgan = require('morgan');
const compression = require('compression');
const cors = require('cors');
const { validationResult } = require('express-validator');

const { corsOptions, generalLimiter, sanitizeBody, helmetConfig, requestId } = require('./middleware/security');
const logger = require('./config/logger');

// ── Rotas ─────────────────────────────────────────────────────────────────────
const authRoutes = require('./modules/auth/auth.routes');
const quotesRoutes = require('./modules/quotes/quotes.routes');
const matchingRoutes = require('./modules/matching/matching.routes');
const paymentsRoutes = require('./modules/payments/payments.routes');
const chatRoutes = require('./modules/chat/chat.routes');
const otpRoutes = require('./modules/otp/otp.routes');
const subscriptionsRoutes = require('./modules/subscriptions/subscriptions.routes');
const servicesRoutes = require('./modules/services/services.routes');
const auditRoutes = require('./modules/audit/audit.routes');
const usersRoutes = require('./modules/users/users.routes');
const citiesRoutes = require('./modules/cities/cities.routes');

const app = express();
app.set('trust proxy', 1);

// ── Middlewares Globais ───────────────────────────────────────────────────────
app.use(requestId);
app.use(helmetConfig);
app.use(cors(corsOptions));
app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(sanitizeBody);
app.use(generalLimiter);

// Logging HTTP (Morgan → Winston)
app.use(morgan('combined', {
  stream: { write: (msg) => logger.http(msg.trim()) },
  skip: (req) => req.path === '/api/health',
}));

// ── Middleware de validação global ───────────────────────────────────────────
app.use((req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({
      success: false,
      message: 'Dados inválidos',
      errors: errors.array().map((e) => ({ field: e.path, message: e.msg })),
    });
  }
  next();
});

// ── Health Check ──────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    success: true,
    status: 'ok',
    timestamp: new Date().toISOString(),
    version: process.env.npm_package_version || '1.0.0',
    environment: process.env.NODE_ENV,
  });
});

// ── Rotas da API ──────────────────────────────────────────────────────────────
app.use('/api/auth', authRoutes);
app.use('/api/quotes', quotesRoutes);
app.use('/api/matching', matchingRoutes);
app.use('/api/payments', paymentsRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/otp', otpRoutes);
app.use('/api/subscriptions', subscriptionsRoutes);
app.use('/api/services', servicesRoutes);
app.use('/api/audit', auditRoutes);
app.use('/api/users', usersRoutes);
app.use('/api/cities', citiesRoutes);

// ── 404 Handler ───────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ success: false, message: `Rota não encontrada: ${req.method} ${req.path}` });
});

// ── Error Handler Global ──────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  // Erro de CORS
  if (err.message && err.message.includes('CORS')) {
    return res.status(403).json({ success: false, message: err.message });
  }

  logger.error('Erro não tratado', {
    error: err.message,
    stack: process.env.NODE_ENV !== 'production' ? err.stack : undefined,
    path: req.path,
    method: req.method,
    requestId: req.id,
  });

  const statusCode = err.status || err.statusCode || 500;
  return res.status(statusCode).json({
    success: false,
    message: process.env.NODE_ENV === 'production' ? 'Erro interno do servidor' : err.message,
    requestId: req.id,
  });
});

module.exports = app;
