const Redis = require('ioredis');
const logger = require('./logger');

const redisConfig = {
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT) || 6379,
  password: process.env.REDIS_PASSWORD || undefined,
  retryStrategy: (times) => {
    const delay = Math.min(times * 50, 2000);
    return delay;
  },
  maxRetriesPerRequest: 3,
  lazyConnect: true,
};

const redis = new Redis(redisConfig);

redis.on('connect', () => logger.info('✅ Redis conectado com sucesso'));
redis.on('error', (err) => logger.error('❌ Erro no Redis', { error: err.message }));
redis.on('reconnecting', () => logger.warn('⚠️  Redis reconectando...'));

// Helper: Obter valor (parsed de JSON se possível)
const get = async (key) => {
  const val = await redis.get(key);
  if (val === null) return null;
  try { return JSON.parse(val); } catch { return val; }
};

// Helper: Setar valor com TTL (em segundos)
const set = async (key, value, ttlSeconds = null) => {
  const serialized = typeof value === 'object' ? JSON.stringify(value) : String(value);
  if (ttlSeconds) {
    return redis.set(key, serialized, 'EX', ttlSeconds);
  }
  return redis.set(key, serialized);
};

// Helper: Deletar chave
const del = async (key) => redis.del(key);

// Helper: Verificar existência
const exists = async (key) => redis.exists(key);

module.exports = { redis, get, set, del, exists };
