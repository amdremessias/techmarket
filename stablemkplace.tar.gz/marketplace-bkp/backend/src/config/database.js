require('dotenv').config({ path: require('path').resolve(__dirname, '../../../.env') });
const { Pool } = require('pg');
const logger = require('./logger');

const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT, 10) || 5432,
  database: process.env.DB_NAME || 'marketplace',
  user: process.env.DB_USER || 'marketplace_user',
  password: process.env.DB_PASSWORD,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

pool.on('error', (err) => {
  logger.error('Unexpected PostgreSQL pool error', { error: err.message });
});

pool.query('SELECT NOW()')
  .then(() => logger.info('PostgreSQL conectado com sucesso'))
  .catch((err) => {
    logger.error('Falha ao conectar ao PostgreSQL', { error: err.message });
    process.exit(1);
  });

const query = async (text, params) => {
  const start = Date.now();
  try {
    const result = await pool.query(text, params);
    const duration = Date.now() - start;
    if (process.env.NODE_ENV === 'development') {
      logger.debug('Query executada', { text, duration, rows: result.rowCount });
    }
    return result;
  } catch (err) {
    logger.error('Erro na query SQL', { text, error: err.message });
    throw err;
  }
};

module.exports = { pool, query };
