const nodemailer = require('nodemailer');
const logger = require('./logger');

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT) || 587,
  secure: process.env.SMTP_SECURE === 'true',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

// Verifica conexão SMTP ao inicializar (apenas em produção)
if (process.env.NODE_ENV === 'production') {
  transporter.verify((error) => {
    if (error) {
      logger.error('❌ Falha na conexão SMTP', { error: error.message });
    } else {
      logger.info('✅ SMTP pronto para enviar e-mails');
    }
  });
}

/**
 * Envia e-mail com OTP de conclusão de serviço
 */
const sendOTPEmail = async ({ to, name, otp, quoteId }) => {
  const mailOptions = {
    from: process.env.EMAIL_FROM,
    to,
    subject: '🔐 Código de Confirmação — Conclusão de Serviço',
    html: `
      <div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #0f172a; color: #e2e8f0; border-radius: 12px; overflow: hidden;">
        <div style="background: linear-gradient(135deg, #6366f1, #8b5cf6); padding: 32px; text-align: center;">
          <h1 style="margin: 0; font-size: 24px; font-weight: 700; color: #fff;">Marketplace Serviços</h1>
          <p style="margin: 8px 0 0; color: #c4b5fd; font-size: 14px;">Confirmação de Conclusão</p>
        </div>
        <div style="padding: 40px 32px;">
          <p style="font-size: 16px; margin-bottom: 8px;">Olá, <strong>${name}</strong>!</p>
          <p style="color: #94a3b8; margin-bottom: 32px;">
            O prestador de serviços concluiu o trabalho referente ao orçamento <strong>#${quoteId.substring(0, 8).toUpperCase()}</strong>. 
            Use o código abaixo para confirmar a conclusão:
          </p>
          <div style="background: #1e293b; border: 1px solid #334155; border-radius: 12px; padding: 32px; text-align: center; margin-bottom: 32px;">
            <p style="color: #64748b; font-size: 12px; text-transform: uppercase; letter-spacing: 2px; margin: 0 0 12px;">Código OTP</p>
            <div style="font-size: 48px; font-weight: 800; letter-spacing: 8px; color: #6366f1;">${otp}</div>
            <p style="color: #f59e0b; font-size: 12px; margin: 16px 0 0;">⚠️ Válido por ${process.env.OTP_EXPIRES_MINUTES || 30} minutos</p>
          </div>
          <p style="color: #64748b; font-size: 13px; line-height: 1.6;">
            Se você não reconhece este serviço, ignore este e-mail e entre em contato com nosso suporte imediatamente.
          </p>
        </div>
        <div style="background: #0a0f1e; padding: 20px 32px; text-align: center;">
          <p style="color: #475569; font-size: 12px; margin: 0;">© ${new Date().getFullYear()} Marketplace de Serviços Técnicos. Todos os direitos reservados.</p>
        </div>
      </div>
    `,
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    logger.info('E-mail OTP enviado', { to, messageId: info.messageId, quoteId });
    return info;
  } catch (err) {
    logger.error('Falha ao enviar e-mail OTP', { to, error: err.message });
    throw err;
  }
};

/**
 * Envia e-mail de boas-vindas ao novo usuário
 */
const sendWelcomeEmail = async ({ to, name }) => {
  const mailOptions = {
    from: process.env.EMAIL_FROM,
    to,
    subject: '🎉 Bem-vindo ao Marketplace de Serviços!',
    html: `
      <div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #0f172a; color: #e2e8f0; border-radius: 12px; overflow: hidden;">
        <div style="background: linear-gradient(135deg, #6366f1, #8b5cf6); padding: 32px; text-align: center;">
          <h1 style="margin: 0; font-size: 24px; font-weight: 700; color: #fff;">Marketplace Serviços</h1>
        </div>
        <div style="padding: 40px 32px;">
          <p style="font-size: 18px; font-weight: 600; margin-bottom: 8px;">Olá, ${name}! 👋</p>
          <p style="color: #94a3b8;">Sua conta foi criada com sucesso. Comece a usar a plataforma agora mesmo!</p>
        </div>
      </div>
    `,
  };
  try {
    await transporter.sendMail(mailOptions);
    logger.info('E-mail de boas-vindas enviado', { to });
  } catch (err) {
    logger.warn('Falha ao enviar e-mail de boas-vindas (não crítico)', { error: err.message });
  }
};

module.exports = { sendOTPEmail, sendWelcomeEmail };
