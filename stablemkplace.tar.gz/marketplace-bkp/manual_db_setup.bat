@echo off
echo Setting up Marketplace database manually...

echo 1. Make sure PostgreSQL is running
echo 2. Run these commands manually in psql:
echo.
echo psql -U postgres -c "CREATE DATABASE marketplace;"
echo psql -U postgres -c "CREATE USER marketplace_user WITH PASSWORD 'marketplace_password_123!';"
echo psql -U postgres -c "GRANT ALL PRIVILEGES ON DATABASE marketplace TO marketplace_user;"
echo psql -U postgres -d marketplace -f database\init.sql
echo.
echo 3. Then restart the backend server
echo.