'use client';
import { useState, useEffect, useRef } from 'react';
import DashboardLayout from '../dashboard/layout';
import api from '../../lib/api';

export default function ChatPage() {
  const [conversations, setConversations] = useState([]);
  const [selectedChat, setSelectedChat] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const scrollRef = useRef();

  useEffect(() => {
    loadConversations();
  }, []);

  useEffect(() => {
    if (selectedChat) {
      loadMessages(selectedChat.id);
      // Aqui poderíamos iniciar um polling ou socket
      const interval = setInterval(() => loadMessages(selectedChat.id), 5000);
      return () => clearInterval(interval);
    }
  }, [selectedChat]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const loadConversations = async () => {
    try {
      // Listar quotes ativos (onde há chat)
      const res = await api.get('/quotes').catch(() => ({ data: [] }));
      setConversations(Array.isArray(res.data) ? res.data : []);
    } finally {
      setLoading(false);
    }
  };

  const loadMessages = async (quoteId) => {
    try {
      const res = await api.get(`/chat/${quoteId}`).catch(() => ({ data: [] }));
      setMessages(Array.isArray(res.data) ? res.data : []);
    } catch (err) {}
  };

  const handleSend = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedChat) return;

    try {
      const res = await api.post(`/chat/${selectedChat.id}`, { content: newMessage });
      setMessages([...messages, res.data]);
      setNewMessage('');
    } catch (err) {
      alert('Erro ao enviar mensagem');
    }
  };

  return (
    <DashboardLayout>
      <div className="card-glass" style={{ height: 'calc(100vh - 200px)', display: 'flex', overflow: 'hidden', padding: 0 }}>
        {/* Lista de Conversas */}
        <div style={{ width: '320px', borderRight: '1px solid var(--color-border)', display: 'flex', flexDirection: 'column' }}>
          <div style={{ padding: '24px', borderBottom: '1px solid var(--color-border)' }}>
            <h3 style={{ fontSize: '1.1rem' }}>Conversas</h3>
          </div>
          <div style={{ flex: 1, overflowY: 'auto' }}>
            {conversations.map((chat) => (
              <div 
                key={chat.id} 
                onClick={() => setSelectedChat(chat)}
                style={{ 
                  padding: '20px', 
                  cursor: 'pointer',
                  background: selectedChat?.id === chat.id ? 'rgba(99,102,241,0.1)' : 'transparent',
                  borderBottom: '1px solid rgba(255,255,255,0.03)',
                  transition: 'all 0.2s'
                }}
              >
                <div style={{ fontWeight: 600, fontSize: '0.9rem', marginBottom: '4px' }}>{chat.category_name}</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--color-text-2)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {chat.description}
                </div>
              </div>
            ))}
            {conversations.length === 0 && (
              <p style={{ textAlign: 'center', padding: '40px', color: 'var(--color-text-2)', fontSize: '0.85rem' }}>Nenhuma conversa ativa.</p>
            )}
          </div>
        </div>

        {/* Área do Chat */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'rgba(0,0,0,0.1)' }}>
          {selectedChat ? (
            <>
              <div style={{ padding: '20px 32px', borderBottom: '1px solid var(--color-border)', background: 'var(--color-surface)' }}>
                <h4 style={{ fontSize: '1rem' }}>{selectedChat.category_name}</h4>
                <p style={{ fontSize: '0.75rem', color: 'var(--color-text-2)' }}>Status: {selectedChat.status}</p>
              </div>

              <div ref={scrollRef} style={{ flex: 1, padding: '32px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '16px' }}>
                {messages.map((msg, i) => {
                  const isMe = msg.sender_id === JSON.parse(localStorage.getItem('user'))?.id;
                  return (
                    <div key={msg.id || i} style={{ 
                      alignSelf: isMe ? 'flex-end' : 'flex-start',
                      maxWidth: '70%',
                      padding: '12px 18px',
                      borderRadius: isMe ? '16px 16px 2px 16px' : '16px 16px 16px 2px',
                      background: isMe ? 'var(--color-primary)' : 'rgba(255,255,255,0.08)',
                      color: isMe ? 'white' : 'var(--color-text-1)',
                      fontSize: '0.9rem',
                      boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                    }}>
                      {!isMe && <div style={{ fontSize: '0.7rem', opacity: 0.6, marginBottom: '4px' }}>{msg.sender_name}</div>}
                      {msg.content}
                    </div>
                  );
                })}
              </div>

              <form onSubmit={handleSend} style={{ padding: '24px 32px', background: 'var(--color-surface)', display: 'flex', gap: '12px' }}>
                <input 
                  type="text" 
                  className="form-input" 
                  placeholder="Escreva sua mensagem..." 
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  style={{ borderRadius: '24px' }}
                />
                <button type="submit" className="btn btn-primary" style={{ borderRadius: '50%', width: '48px', height: '48px', padding: 0 }}>
                  ✈️
                </button>
              </form>
            </>
          ) : (
            <div className="flex-center" style={{ flex: 1, flexDirection: 'column', color: 'var(--color-text-2)' }}>
              <div style={{ fontSize: '4rem', marginBottom: '20px' }}>💬</div>
              <p>Selecione uma conversa para começar</p>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
