import './globals.css';

export const metadata = {
  title: 'Marketplace de Serviços Técnicos',
  description: 'Conectamos clientes a prestadores de serviços técnicos qualificados: Redes, CFTV, TI, Fibra Óptica e muito mais.',
  keywords: 'serviços técnicos, redes, CFTV, TI, orçamento, prestadores',
  openGraph: {
    title: 'Marketplace de Serviços Técnicos',
    description: 'Encontre os melhores técnicos próximos a você',
    type: 'website',
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="pt-BR">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body>{children}</body>
    </html>
  );
}
