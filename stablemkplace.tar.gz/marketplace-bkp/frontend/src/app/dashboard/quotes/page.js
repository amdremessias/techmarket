'use client';
import { useState } from 'react';

export default function QuotesPage() {
  return (
    <div className="card-glass" style={{ padding: '40px', textAlign: 'center' }}>
      <div style={{ fontSize: '3rem', marginBottom: '20px' }}>📋</div>
      <h2>Minhas Cotações</h2>
      <p style={{ color: 'var(--color-text-2)', marginTop: '12px' }}>Você ainda não possui histórico de cotações.</p>
    </div>
  );
}
