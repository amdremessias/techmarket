'use client';
import { useState, useEffect } from 'react';
import DashboardLayout from '../layout';
import api from '../../../lib/api';

export default function ProfilePage() {
  const [user, setUser] = useState({ name: '', email: '', phone: '' });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    const stored = localStorage.getItem('user');
    if (stored) setUser(JSON.parse(stored));
  }, []);

  const handleUpdate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await api.patch('/auth/profile', user);
      localStorage.setItem('user', JSON.stringify(res.data));
      setMessage('Perfil atualizado com sucesso!');
      setTimeout(() => setMessage(''), 3000);
    } catch (err) {
      alert('Erro ao atualizar perfil');
    } finally {
      setLoading(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="card-glass" style={{ maxWidth: '600px', margin: '0 auto', padding: '40px' }}>
        <h2 style={{ fontSize: '1.5rem', marginBottom: '8px' }}>Meu Perfil</h2>
        <p style={{ color: 'var(--color-text-2)', marginBottom: '32px' }}>Gerencie suas informações pessoais e de contato.</p>

        <form onSubmit={handleUpdate}>
          <div className="form-group">
            <label className="form-label">Nome Completo</label>
            <input 
              type="text" 
              className="form-input" 
              value={user.name}
              onChange={(e) => setUser({ ...user, name: e.target.value })}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">E-mail</label>
            <input 
              type="email" 
              className="form-input" 
              value={user.email}
              disabled
              style={{ opacity: 0.6 }}
            />
            <small style={{ color: 'var(--color-text-2)', display: 'block', marginTop: '4px' }}>O e-mail não pode ser alterado.</small>
          </div>

          <div className="form-group">
            <label className="form-label">Telefone / WhatsApp</label>
            <input 
              type="text" 
              className="form-input" 
              placeholder="(00) 00000-0000"
              value={user.phone || ''}
              onChange={(e) => setUser({ ...user, phone: e.target.value })}
            />
          </div>

          {message && (
            <div style={{ 
              padding: '12px', borderRadius: '8px', background: 'rgba(34,197,94,0.1)', 
              color: 'var(--color-success-light)', marginBottom: '24px', textAlign: 'center' 
            }}>
              {message}
            </div>
          )}

          <button type="submit" className="btn btn-primary btn-full" disabled={loading}>
            {loading ? 'Salvando...' : 'Salvar Alterações'}
          </button>
        </form>
      </div>
    </DashboardLayout>
  );
}
