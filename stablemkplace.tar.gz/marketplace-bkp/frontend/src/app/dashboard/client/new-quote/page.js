'use client';
import { useState, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import api from '../../../../lib/api';

function NewQuoteForm() {
  const searchParams = useSearchParams();
  const serviceId = searchParams.get('serviceId');
  const serviceName = searchParams.get('name');
  
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.post('/quotes', {
        category_id: serviceId,
        description: description,
        // Por agora, usamos uma localização padrão ou deixamos opcional
      });
      setSuccess(true);
    } catch (err) {
      alert('Erro ao enviar solicitação');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="card-glass text-center" style={{ padding: '60px' }}>
        <div style={{ fontSize: '4rem', marginBottom: '24px' }}>✅</div>
        <h2 style={{ fontSize: '2rem', marginBottom: '16px' }}>Solicitação Enviada!</h2>
        <p style={{ color: 'var(--color-text-2)', marginBottom: '32px' }}>
          Sua solicitação de <strong>{serviceName}</strong> foi enviada para os técnicos da região. 
          Você receberá notificações assim que os orçamentos começarem a chegar.
        </p>
        <Link href="/dashboard/client" className="btn btn-primary">Voltar ao Início</Link>
      </div>
    );
  }

  return (
    <div className="card-glass" style={{ maxWidth: '600px', margin: '0 auto', padding: '40px' }}>
      <h2 style={{ fontSize: '1.5rem', marginBottom: '8px' }}>Solicitar {serviceName}</h2>
      <p style={{ color: 'var(--color-text-2)', marginBottom: '32px', fontSize: '0.9rem' }}>
        Descreva detalhadamente o que você precisa para que os técnicos enviem orçamentos precisos.
      </p>

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="form-label">Descrição do Problema/Serviço</label>
          <textarea 
            className="form-input" 
            style={{ minHeight: '150px', padding: '16px', lineHeight: '1.6' }}
            placeholder="Ex: Meu ar condicionado parou de gelar e está fazendo um barulho estranho..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          />
        </div>

        <button type="submit" className="btn btn-primary btn-full" disabled={loading || !description}>
          {loading ? 'Enviando...' : 'Enviar Solicitação'}
        </button>
        
        <Link href="/dashboard/client" style={{ display: 'block', textAlign: 'center', marginTop: '20px', color: 'var(--color-text-2)', textDecoration: 'none', fontSize: '0.9rem' }}>
          Cancelar
        </Link>
      </form>
    </div>
  );
}

export default function NewQuotePage() {
  return (
    <Suspense fallback={<div className="flex-center" style={{height: '100vh'}}><div className="spinner" /></div>}>
      <NewQuoteForm />
    </Suspense>
  );
}
