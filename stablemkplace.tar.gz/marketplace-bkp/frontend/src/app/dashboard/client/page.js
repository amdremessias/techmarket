'use client';
import { useState, useEffect } from 'react';
import api from '../../../lib/api';

export default function ClientDashboard() {
  const [stats, setStats] = useState({ activeQuotes: 0, pendingPayments: 0, completedServices: 0 });
  const [services, setServices] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    try {
      const res = await api.get('/services').catch(() => ({ data: [] }));
      setServices(Array.isArray(res.data) ? res.data : []);
    } catch (err) {
      console.error('Erro ao carregar serviços:', err);
    }
  };

  const filteredServices = services.filter(s => 
    s.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
      {/* Stats Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '24px' }}>
        <div className="card-glass" style={{ padding: '24px' }}>
          <h3 style={{ fontSize: '0.9rem', color: 'var(--color-text-2)', marginBottom: '8px' }}>Solicitações Ativas</h3>
          <p style={{ fontSize: '2rem', fontWeight: 700 }}>{stats.activeQuotes}</p>
        </div>
        <div className="card-glass" style={{ padding: '24px' }}>
          <h3 style={{ fontSize: '0.9rem', color: 'var(--color-text-2)', marginBottom: '8px' }}>Pagamentos Pendentes</h3>
          <p style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--color-warning-light)' }}>{stats.pendingPayments}</p>
        </div>
        <div className="card-glass" style={{ padding: '24px' }}>
          <h3 style={{ fontSize: '0.9rem', color: 'var(--color-text-2)', marginBottom: '8px' }}>Serviços Finalizados</h3>
          <p style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--color-success-light)' }}>{stats.completedServices}</p>
        </div>
      </div>

      {/* Search and Services */}
      <div className="card-glass" style={{ padding: '32px' }}>
        <div style={{ marginBottom: '32px' }}>
          <h3 style={{ fontSize: '1.25rem', marginBottom: '16px' }}>Do que você precisa hoje?</h3>
          <div style={{ position: 'relative' }}>
            <span style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)', opacity: 0.5 }}>🔍</span>
            <input 
              type="text" 
              className="form-input" 
              placeholder="Ex: Eletricista, Encanador, TI..." 
              style={{ paddingLeft: '48px', height: '54px', fontSize: '1rem' }}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '20px' }}>
          {filteredServices.map((service) => (
            <Link 
              key={service.id}
              href={`/dashboard/client/new-quote?serviceId=${service.id}&name=${encodeURIComponent(service.name)}`}
              className="card-glass"
              style={{ 
                padding: '24px', 
                textAlign: 'center', 
                textDecoration: 'none', 
                transition: 'all 0.2s',
                background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.05)'
              }}
              onMouseOver={(e) => e.currentTarget.style.transform = 'translateY(-5px)'}
              onMouseOut={(e) => e.currentTarget.style.transform = 'translateY(0)'}
            >
              <div style={{ fontSize: '2rem', marginBottom: '12px' }}>🛠️</div>
              <h4 style={{ color: 'var(--color-text-1)', fontSize: '1rem' }}>{service.name}</h4>
              <p style={{ fontSize: '0.75rem', color: 'var(--color-text-2)', marginTop: '8px' }}>Solicitar Orçamento</p>
            </Link>
          ))}
          {filteredServices.length === 0 && (
            <p style={{ gridColumn: '1 / -1', textAlign: 'center', padding: '40px', color: 'var(--color-text-2)' }}>
              Nenhum serviço encontrado para sua busca.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

// Nota: Importar Link se necessário, mas o layout já cuida da navegação.
// No Next.js App Router, Link vem de 'next/link'.
import Link from 'next/link';
