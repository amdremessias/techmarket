'use client';
import { useState, useEffect } from 'react';
import api from '../../../lib/api';

export default function ProviderDashboard() {
  const [stats, setStats] = useState({ newRequests: 0, activeJobs: 0, totalEarnings: 'R$ 0,00' });
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    loadJobs();
  }, []);

  const loadJobs = async () => {
    try {
      // Nota: GET /api/quotes/available deve retornar cotações PENDING na região do técnico
      const res = await api.get('/quotes?type=available').catch(() => ({ data: [] }));
      setJobs(Array.isArray(res.data) ? res.data : []);
    } catch (err) {}
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
      {/* Stats Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '24px' }}>
        <div className="card-glass" style={{ padding: '24px', borderLeft: '4px solid var(--color-primary)' }}>
          <h3 style={{ fontSize: '0.9rem', color: 'var(--color-text-2)', marginBottom: '8px' }}>Novos Pedidos</h3>
          <p style={{ fontSize: '2rem', fontWeight: 700 }}>{jobs.length}</p>
        </div>
        <div className="card-glass" style={{ padding: '24px', borderLeft: '4px solid var(--color-warning)' }}>
          <h3 style={{ fontSize: '0.9rem', color: 'var(--color-text-2)', marginBottom: '8px' }}>Serviços em Andamento</h3>
          <p style={{ fontSize: '2rem', fontWeight: 700 }}>{stats.activeJobs}</p>
        </div>
        <div className="card-glass" style={{ padding: '24px', borderLeft: '4px solid var(--color-success)' }}>
          <h3 style={{ fontSize: '0.9rem', color: 'var(--color-text-2)', marginBottom: '8px' }}>Ganhos Totais</h3>
          <p style={{ fontSize: '2rem', fontWeight: 700 }}>{stats.totalEarnings}</p>
        </div>
      </div>

      <div className="card-glass" style={{ padding: '32px' }}>
        <h3 style={{ fontSize: '1.25rem', marginBottom: '24px' }}>Oportunidades Disponíveis</h3>
        
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {jobs.length > 0 ? jobs.map((job) => (
            <div key={job.id} className="card-glass" style={{ padding: '24px', background: 'rgba(255,255,255,0.02)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
                <div>
                  <span style={{ fontSize: '0.75rem', color: 'var(--color-primary-light)', fontWeight: 600, textTransform: 'uppercase' }}>
                    {job.category_name || 'Serviço'}
                  </span>
                  <h4 style={{ fontSize: '1.15rem', marginTop: '4px' }}>{job.client_name || 'Cliente'}</h4>
                </div>
                <span style={{ fontSize: '0.8rem', color: 'var(--color-text-2)' }}>
                  {new Date(job.created_at).toLocaleDateString()}
                </span>
              </div>
              <p style={{ color: 'var(--color-text-2)', fontSize: '0.95rem', marginBottom: '20px', lineHeight: '1.5' }}>
                {job.description}
              </p>
              <div style={{ display: 'flex', gap: '12px' }}>
                <button className="btn btn-primary" style={{ padding: '8px 20px' }}>Enviar Orçamento</button>
                <button className="btn" style={{ padding: '8px 20px', border: '1px solid var(--color-border)' }}>Ignorar</button>
              </div>
            </div>
          )) : (
            <div style={{ textAlign: 'center', padding: '40px', color: 'var(--color-text-2)' }}>
              <p>Nenhuma oportunidade disponível no momento. Fique ligado!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
