'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

import { APP_CONFIG } from '../../lib/config';

export default function DashboardLayout({ children }) {
  const [user, setUser] = useState(null);
  const pathname = usePathname();

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    } else {
      window.location.href = '/auth/login';
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/auth/login';
  };

  if (!user) return <div className="flex-center" style={{ height: '100vh' }}><div className="spinner" /></div>;

  const menuItems = [
    { name: 'Início', path: user.role === 'admin' ? '/admin' : `/dashboard/${user.role}`, icon: '🏠' },
    ...(user.role === 'admin' ? [
      { name: 'Usuários', path: '/admin/users', icon: '👥' },
      { name: 'Serviços', path: '/admin/categories', icon: '🛠️' },
      { name: 'Cidades', path: '/admin/cities', icon: '📍' },
      { name: 'Meu Perfil', path: '/admin/profile', icon: '🔑' },
    ] : [
      { name: 'Cotações', path: '/dashboard/quotes', icon: '📋' },
      { name: 'Chat', path: '/chat', icon: '💬' },
      { name: 'Perfil', path: '/dashboard/profile', icon: '👤' },
    ]),
  ];

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      {/* Sidebar */}
      <aside style={{
        width: '260px',
        background: 'var(--color-surface)',
        borderRight: '1px solid var(--color-border)',
        padding: '24px',
        display: 'flex',
        flexDirection: 'column',
      }}>
        <div style={{ marginBottom: '40px' }}>
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.25rem' }}>
            <span className="gradient-text">{APP_CONFIG.logoText.substring(0, 4)}</span>{APP_CONFIG.logoText.substring(4)}
          </span>
        </div>

        <nav style={{ flex: 1 }}>
          {menuItems.map((item) => (
            <Link 
              key={item.path} 
              href={item.path}
              style={{
                display: 'flex',
                alignItems: 'center',
                padding: '12px 16px',
                borderRadius: 'var(--radius-md)',
                textDecoration: 'none',
                color: pathname === item.path ? 'var(--color-primary-light)' : 'var(--color-text-2)',
                background: pathname === item.path ? 'rgba(99,102,241,0.08)' : 'transparent',
                marginBottom: '8px',
                transition: 'all 0.2s',
              }}
            >
              <span style={{ marginRight: '12px', fontSize: '1.2rem' }}>{item.icon}</span>
              {item.name}
            </Link>
          ))}
        </nav>

        <button 
          onClick={handleLogout}
          style={{
            background: 'transparent',
            border: 'none',
            color: 'var(--color-danger-light)',
            display: 'flex',
            alignItems: 'center',
            padding: '12px 16px',
            cursor: 'pointer',
            fontSize: '0.9rem',
          }}
        >
          <span style={{ marginRight: '12px' }}>🚪</span> Sair
        </button>
      </aside>

      {/* Main Content */}
      <main style={{ flex: 1, padding: '40px', background: 'var(--color-bg)' }}>
        <header style={{ marginBottom: '32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h2 style={{ fontSize: '1.5rem', marginBottom: '4px' }}>Olá, {user.name} 👋</h2>
            <p style={{ color: 'var(--color-text-2)', fontSize: '0.9rem' }}>Bem-vindo ao seu painel de {user.role === 'admin' ? 'Administrador' : user.role === 'provider' ? 'Prestador' : 'Cliente'}.</p>
          </div>
          <div style={{ display: 'flex', alignItems: 'center' }}>
             <div style={{
               width: '40px', height: '40px', borderRadius: '50%',
               background: 'var(--color-primary)', display: 'flex', alignItems: 'center', justifyContent: 'center',
               fontWeight: 600, color: 'white', marginRight: '12px'
             }}>
               {user.name.charAt(0)}
             </div>
          </div>
        </header>

        {children}
      </main>
    </div>
  );
}
