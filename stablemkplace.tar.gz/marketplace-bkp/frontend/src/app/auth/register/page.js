'use client';
import { useEffect, useState, Suspense } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import api from '../../../lib/api';

function RegisterForm() {
  const searchParams = useSearchParams();
  const defaultRole = searchParams?.get('role') || 'client';
  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    role: defaultRole,
    categoryIds: [],
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/services')
      .then((res) => setCategories((res.data || []).filter((cat) => cat.is_active)))
      .catch(() => setCategories([]));
  }, []);

  const toggleCategory = (id) => {
    setForm((current) => ({
      ...current,
      categoryIds: current.categoryIds.includes(id)
        ? current.categoryIds.filter((item) => item !== id)
        : [...current.categoryIds, id],
    }));
  };

  const handleRole = (role) => {
    setForm((current) => ({
      ...current,
      role,
      categoryIds: role === 'provider' ? current.categoryIds : [],
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    if (form.role === 'provider' && form.categoryIds.length === 0) {
      setError('Selecione pelo menos uma categoria de atuacao.');
      setLoading(false);
      return;
    }

    try {
      const payload = {
        ...form,
        phone: form.role === 'provider' ? form.phone : undefined,
        categoryIds: form.role === 'provider' ? form.categoryIds : undefined,
      };
      const data = await api.post('/auth/register', payload);
      localStorage.setItem('token', data.data.accessToken);
      localStorage.setItem('user', JSON.stringify(data.data.user));
      window.location.href = form.role === 'provider' ? '/dashboard/provider' : '/dashboard/client';
    } catch (err) {
      setError(err.response?.data?.message || err.response?.data?.errors?.[0]?.message || 'Erro ao criar conta');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'radial-gradient(ellipse at center, rgba(99,102,241,0.08) 0%, var(--color-bg) 60%)',
      padding: '24px',
    }}>
      <div style={{ width: '100%', maxWidth: '560px' }}>
        <div className="text-center" style={{ marginBottom: '32px' }}>
          <Link href="/" style={{ textDecoration: 'none' }}>
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.5rem' }}>
              <span className="gradient-text">Tech</span>Market
            </span>
          </Link>
          <h1 style={{ fontSize: '1.5rem', marginTop: '24px', marginBottom: '8px' }}>Crie sua conta</h1>
          <p style={{ fontSize: '0.9rem' }}>Escolha seu perfil e complete o cadastro.</p>
        </div>

        <div className="card-glass" style={{ padding: '32px', borderRadius: 'var(--radius-xl)' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '24px' }}>
            {[
              { role: 'client', label: 'Quero contratar', desc: 'Solicitar servicos' },
              { role: 'provider', label: 'Sou tecnico', desc: 'Prestar servicos' },
            ].map((opt) => (
              <button
                key={opt.role}
                type="button"
                onClick={() => handleRole(opt.role)}
                style={{
                  padding: '16px',
                  borderRadius: 'var(--radius-md)',
                  cursor: 'pointer',
                  border: form.role === opt.role ? '2px solid var(--color-primary)' : '1px solid var(--color-border-2)',
                  background: form.role === opt.role ? 'rgba(99,102,241,0.1)' : 'var(--color-bg-2)',
                  color: 'var(--color-text)',
                  textAlign: 'center',
                  transition: 'var(--transition)',
                }}
              >
                <div style={{ fontWeight: 700, fontSize: '0.9rem' }}>{opt.label}</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--color-text-3)', marginTop: '4px' }}>{opt.desc}</div>
              </button>
            ))}
          </div>

          {error && (
            <div style={{
              background: 'rgba(239,68,68,0.1)',
              border: '1px solid rgba(239,68,68,0.3)',
              borderRadius: 'var(--radius-md)',
              padding: '12px 16px',
              color: 'var(--color-danger-light)',
              fontSize: '0.875rem',
              marginBottom: '20px',
            }}>
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Nome completo</label>
              <input className="form-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
            </div>
            <div className="form-group">
              <label className="form-label">E-mail</label>
              <input type="email" className="form-input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
            </div>
            {form.role === 'provider' && (
              <>
                <div className="form-group">
                  <label className="form-label">Telefone / WhatsApp</label>
                  <input type="tel" className="form-input" placeholder="11999999999" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                </div>
                <div className="form-group">
                  <label className="form-label">Categorias de atuacao</label>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: '8px' }}>
                    {categories.map((cat) => (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => toggleCategory(cat.id)}
                        style={{
                          padding: '10px',
                          borderRadius: '8px',
                          border: form.categoryIds.includes(cat.id) ? '1px solid var(--color-primary)' : '1px solid var(--color-border)',
                          background: form.categoryIds.includes(cat.id) ? 'rgba(99,102,241,0.12)' : 'transparent',
                          color: 'var(--color-text)',
                          cursor: 'pointer',
                          textAlign: 'left',
                        }}
                      >
                        {cat.name}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}
            <div className="form-group">
              <label className="form-label">Senha</label>
              <input type="password" className="form-input" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required minLength={8} />
              <span className="form-error" style={{ color: 'var(--color-text-3)', fontSize: '0.75rem' }}>
                Deve conter maiuscula, minuscula e numero.
              </span>
            </div>

            <button type="submit" className="btn btn-primary btn-full" disabled={loading} style={{ marginTop: '8px' }}>
              {loading ? 'Criando conta...' : 'Criar conta gratuita'}
            </button>
          </form>

          <div className="divider" />
          <p style={{ textAlign: 'center', fontSize: '0.875rem', color: 'var(--color-text-2)' }}>
            Ja tem uma conta?{' '}
            <Link href="/auth/login" style={{ color: 'var(--color-primary-light)', textDecoration: 'none', fontWeight: 600 }}>
              Entrar
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default function RegisterPage() {
  return (
    <Suspense fallback={<div>Carregando...</div>}>
      <RegisterForm />
    </Suspense>
  );
}
