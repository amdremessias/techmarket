'use client';
import Link from 'next/link';

const FEATURES = [
  { icon: '📍', title: 'Matchmaking Geográfico', desc: 'Encontramos os melhores técnicos nos seus arredores via GPS em tempo real.' },
  { icon: '🔒', title: 'Pagamento em Custódia', desc: 'R$100 ficam retidos até você confirmar a conclusão do serviço com código OTP.' },
  { icon: '💬', title: 'Chat Interno', desc: 'Comunique-se diretamente com o prestador sem expor seus dados pessoais.' },
  { icon: '⭐', title: 'Prestadores Verificados', desc: 'Todos os técnicos passam por validação e são avaliados pelos clientes.' },
];

const CATEGORIES = [
  { icon: '🌐', name: 'Redes & Infraestrutura' },
  { icon: '📹', name: 'CFTV & Segurança' },
  { icon: '💻', name: 'Suporte de TI' },
  { icon: '⚡', name: 'Fibra Óptica' },
  { icon: '🔌', name: 'Cabeamento Estruturado' },
  { icon: '🖥️', name: 'Servidores & Cloud' },
  { icon: '🏠', name: 'Automação Residencial' },
  { icon: '☀️', name: 'Energia Solar' },
];

const WORKFLOW = [
  { step: '01', title: 'Solicite o serviço', desc: 'Descreva o que precisa e informe sua localização.' },
  { step: '02', title: 'Pague a custódia', desc: 'R$100 ficam bloqueados como garantia do orçamento.' },
  { step: '03', title: 'Receba propostas', desc: 'Técnicos próximos enviam seus orçamentos pelo chat.' },
  { step: '04', title: 'Confirme com OTP', desc: 'Ao concluir, você valida com um código enviado por e-mail.' },
];

export default function HomePage() {
  return (
    <main>
      {/* ── NAVBAR ── */}
      <nav style={{
        position: 'sticky', top: 0, zIndex: 100,
        background: 'rgba(7,11,20,0.85)', backdropFilter: 'blur(20px)',
        borderBottom: '1px solid rgba(255,255,255,0.06)',
        padding: '16px 0',
      }}>
        <div className="container flex justify-between items-center">
          <div className="flex items-center gap-12">
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.25rem' }}>
              <span className="gradient-text">Tech</span>Market
            </span>
            <div className="flex gap-24 hide-mobile">
              <a href="#features" style={{ color: 'var(--color-text-2)', textDecoration: 'none', fontSize: '0.9rem' }}>Funcionalidades</a>
              <a href="#categories" style={{ color: 'var(--color-text-2)', textDecoration: 'none', fontSize: '0.9rem' }}>Categorias</a>
              <a href="#workflow" style={{ color: 'var(--color-text-2)', textDecoration: 'none', fontSize: '0.9rem' }}>Como Funciona</a>
            </div>
          </div>
          <div className="flex gap-8">
            <Link href="/auth/login" className="btn btn-ghost btn-sm">Entrar</Link>
            <Link href="/auth/register" className="btn btn-primary btn-sm">Cadastrar</Link>
          </div>
        </div>
      </nav>

      {/* ── HERO ── */}
      <section style={{
        minHeight: '90vh', display: 'flex', alignItems: 'center',
        position: 'relative', overflow: 'hidden',
        background: 'radial-gradient(ellipse at 60% 50%, rgba(99,102,241,0.12) 0%, transparent 60%)',
      }}>
        {/* Orbs decorativos */}
        <div style={{
          position: 'absolute', width: '600px', height: '600px',
          borderRadius: '50%', top: '-200px', right: '-150px',
          background: 'radial-gradient(circle, rgba(139,92,246,0.08) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />
        <div style={{
          position: 'absolute', width: '400px', height: '400px',
          borderRadius: '50%', bottom: '-100px', left: '-100px',
          background: 'radial-gradient(circle, rgba(6,182,212,0.06) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />

        <div className="container text-center">
          <div className="animate-fade-in" style={{ marginBottom: '16px' }}>
            <span style={{
              display: 'inline-flex', alignItems: 'center', gap: '6px',
              padding: '6px 14px', borderRadius: 'var(--radius-full)',
              background: 'rgba(99,102,241,0.1)', border: '1px solid rgba(99,102,241,0.3)',
              fontSize: '0.8rem', fontWeight: 600, color: 'var(--color-primary-light)',
            }}>
              ⚡ Plataforma de Serviços Técnicos
            </span>
          </div>
          <h1 className="animate-fade-in delay-100" style={{ marginBottom: '24px' }}>
            Conecte-se com os<br />
            <span className="gradient-text">Melhores Técnicos</span><br />
            da sua região
          </h1>
          <p className="animate-fade-in delay-200" style={{
            fontSize: '1.15rem', maxWidth: '600px', margin: '0 auto 40px',
            color: 'var(--color-text-2)',
          }}>
            Redes, CFTV, TI, Fibra Óptica e muito mais — com pagamento em custódia,
            chat integrado e confirmação via código OTP.
          </p>
          <div className="animate-fade-in delay-300 flex justify-center gap-16" style={{ flexWrap: 'wrap' }}>
            <Link href="/auth/register?role=client" className="btn btn-primary btn-lg">
              Solicitar Serviço
            </Link>
            <Link href="/auth/register?role=provider" className="btn btn-outline btn-lg">
              Sou Prestador
            </Link>
          </div>

          {/* Stats */}
          <div className="animate-fade-in flex justify-center gap-24" style={{ marginTop: '64px', flexWrap: 'wrap' }}>
            {[
              { value: '500+', label: 'Técnicos Ativos' },
              { value: '12k+', label: 'Serviços Concluídos' },
              { value: '4.9★', label: 'Avaliação Média' },
              { value: '98%', label: 'Satisfação' },
            ].map((stat) => (
              <div key={stat.label} style={{ textAlign: 'center' }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.8rem', fontWeight: 800, color: 'var(--color-text)' }}>
                  {stat.value}
                </div>
                <div style={{ fontSize: '0.8rem', color: 'var(--color-text-3)', marginTop: '4px' }}>{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FEATURES ── */}
      <section id="features" style={{ padding: '100px 0' }}>
        <div className="container">
          <div className="text-center" style={{ marginBottom: '60px' }}>
            <h2>Por que usar o <span className="gradient-text">TechMarket</span>?</h2>
            <p style={{ marginTop: '12px', fontSize: '1.05rem' }}>Segurança e transparência em cada etapa do serviço</p>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '24px' }}>
            {FEATURES.map((f, i) => (
              <div key={f.title} className="card animate-fade-in" style={{
                animationDelay: `${i * 0.1}s`,
                background: 'linear-gradient(135deg, var(--color-surface), var(--color-bg-2))',
              }}>
                <div style={{ fontSize: '2.5rem', marginBottom: '16px' }}>{f.icon}</div>
                <h3 style={{ fontSize: '1.1rem', marginBottom: '8px' }}>{f.title}</h3>
                <p style={{ fontSize: '0.9rem', lineHeight: 1.7 }}>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CATEGORIES ── */}
      <section id="categories" style={{ padding: '80px 0', background: 'var(--color-bg-2)' }}>
        <div className="container">
          <div className="text-center" style={{ marginBottom: '48px' }}>
            <h2>Categorias de <span className="gradient-text">Serviço</span></h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: '16px' }}>
            {CATEGORIES.map((cat) => (
              <div key={cat.name} style={{
                background: 'var(--color-surface)',
                border: '1px solid var(--color-border-2)',
                borderRadius: 'var(--radius-md)',
                padding: '24px 16px',
                textAlign: 'center',
                cursor: 'pointer',
                transition: 'var(--transition)',
              }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = 'var(--color-border)';
                  e.currentTarget.style.transform = 'translateY(-4px)';
                  e.currentTarget.style.boxShadow = 'var(--shadow-md)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = 'var(--color-border-2)';
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = 'none';
                }}
              >
                <div style={{ fontSize: '2rem', marginBottom: '8px' }}>{cat.icon}</div>
                <div style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--color-text-2)' }}>{cat.name}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── WORKFLOW ── */}
      <section id="workflow" style={{ padding: '100px 0' }}>
        <div className="container">
          <div className="text-center" style={{ marginBottom: '60px' }}>
            <h2>Como <span className="gradient-text">Funciona</span></h2>
            <p style={{ marginTop: '12px' }}>4 passos simples para contratar um serviço</p>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '32px' }}>
            {WORKFLOW.map((w, i) => (
              <div key={w.step} style={{ position: 'relative' }}>
                {i < WORKFLOW.length - 1 && (
                  <div className="hide-mobile" style={{
                    position: 'absolute', top: '24px', right: '-16px',
                    width: '32px', height: '2px',
                    background: 'linear-gradient(90deg, var(--color-primary), transparent)',
                    zIndex: 1,
                  }} />
                )}
                <div style={{
                  width: '48px', height: '48px', borderRadius: '50%',
                  background: 'linear-gradient(135deg, var(--color-primary), var(--color-accent))',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '0.9rem',
                  marginBottom: '20px', boxShadow: 'var(--shadow-glow)',
                }}>
                  {w.step}
                </div>
                <h3 style={{ fontSize: '1rem', marginBottom: '8px' }}>{w.title}</h3>
                <p style={{ fontSize: '0.875rem', lineHeight: 1.7 }}>{w.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section style={{
        padding: '80px 0',
        background: 'linear-gradient(135deg, rgba(99,102,241,0.1), rgba(139,92,246,0.1))',
        borderTop: '1px solid var(--color-border)',
        borderBottom: '1px solid var(--color-border)',
      }}>
        <div className="container text-center">
          <h2 style={{ marginBottom: '16px' }}>Pronto para começar?</h2>
          <p style={{ marginBottom: '32px', fontSize: '1.05rem' }}>
            Crie sua conta gratuitamente e faça seu primeiro orçamento agora mesmo.
          </p>
          <Link href="/auth/register" className="btn btn-primary btn-lg">
            Criar Conta Gratuita →
          </Link>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer style={{
        padding: '40px 0',
        background: 'var(--color-bg)',
        borderTop: '1px solid var(--color-border-2)',
      }}>
        <div className="container flex justify-between items-center" style={{ flexWrap: 'wrap', gap: '16px' }}>
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>
            <span className="gradient-text">Tech</span>Market
          </span>
          <p style={{ fontSize: '0.8rem', margin: 0 }}>
            © {new Date().getFullYear()} Marketplace de Serviços Técnicos. Todos os direitos reservados.
          </p>
        </div>
      </footer>
    </main>
  );
}
