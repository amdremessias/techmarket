'use client';
import { useState, useEffect } from 'react';
import DashboardLayout from '../../dashboard/layout';
import api from '../../../lib/api';

export default function AdminProfile() {
  const [user, setUser]         = useState(null);
  const [loading, setLoading]   = useState(true);

  // Troca de senha
  const [pwdForm, setPwdForm]   = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [pwdSaving, setPwdSaving] = useState(false);
  const [pwdError, setPwdError]   = useState('');
  const [pwdSuccess, setPwdSuccess] = useState('');

  // Aba ativa
  const [tab, setTab] = useState('info'); // 'info' | 'password'

  useEffect(() => {
    api.get('/auth/me')
      .then(res => setUser(res.data))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const handleChangePassword = async (e) => {
    e.preventDefault();
    setPwdError('');
    setPwdSuccess('');

    if (pwdForm.newPassword !== pwdForm.confirm) {
      setPwdError('As novas senhas não coincidem');
      return;
    }
    if (pwdForm.newPassword.length < 8) {
      setPwdError('Mínimo de 8 caracteres para a nova senha');
      return;
    }

    setPwdSaving(true);
    try {
      await api.patch('/users/me/password', {
        currentPassword: pwdForm.currentPassword,
        newPassword:     pwdForm.newPassword,
      });
      setPwdSuccess('Senha alterada com sucesso!');
      setPwdForm({ currentPassword: '', newPassword: '', confirm: '' });
    } catch (err) {
      setPwdError(err.response?.data?.message || 'Erro ao alterar senha');
    } finally {
      setPwdSaving(false);
    }
  };

  const tabStyle = (active) => ({
    padding: '10px 22px',
    borderRadius: '8px',
    border: 'none',
    cursor: 'pointer',
    fontWeight: 600,
    fontSize: '0.9rem',
    transition: 'all 0.2s',
    background: active ? 'var(--color-primary)' : 'transparent',
    color: active ? '#fff' : 'var(--color-text-2)',
  });

  if (loading) return (
    <DashboardLayout>
      <p style={{ textAlign: 'center', padding: '60px', color: 'var(--color-text-2)' }}>Carregando…</p>
    </DashboardLayout>
  );

  return (
    <DashboardLayout>
      <div style={{ maxWidth: '640px', margin: '0 auto' }}>

        {/* Avatar / header */}
        <div className="card-glass" style={{ padding: '32px', marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '24px' }}>
          <div style={{
            width: '72px', height: '72px', borderRadius: '50%',
            background: 'linear-gradient(135deg, var(--color-primary), #a78bfa)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '1.8rem', fontWeight: 700, color: '#fff', flexShrink: 0,
          }}>
            {user?.name?.[0]?.toUpperCase() || 'A'}
          </div>
          <div>
            <h2 style={{ fontSize: '1.4rem', marginBottom: '4px' }}>{user?.name}</h2>
            <p style={{ color: 'var(--color-text-2)', fontSize: '0.9rem', marginBottom: '6px' }}>{user?.email}</p>
            <span style={{
              padding: '3px 12px', borderRadius: '20px', fontSize: '0.75rem', fontWeight: 700,
              background: 'rgba(124,58,237,0.2)', color: 'var(--color-primary)',
            }}>
              {user?.role === 'admin' ? '👑 Administrador' : user?.role}
            </span>
          </div>
        </div>

        {/* Tabs */}
        <div className="card-glass" style={{ padding: '32px' }}>
          <div style={{ display: 'flex', gap: '8px', marginBottom: '28px', background: 'rgba(0,0,0,0.2)', padding: '6px', borderRadius: '10px' }}>
            <button style={tabStyle(tab === 'info')} onClick={() => setTab('info')}>📋 Informações</button>
            <button style={tabStyle(tab === 'password')} onClick={() => setTab('password')}>🔑 Alterar Senha</button>
          </div>

          {/* Tab: Informações */}
          {tab === 'info' && (
            <div>
              {[
                { label: 'Nome completo', value: user?.name },
                { label: 'E-mail', value: user?.email },
                { label: 'Perfil', value: user?.role === 'admin' ? 'Administrador' : user?.role },
                { label: 'Conta criada em', value: user?.created_at ? new Date(user.created_at).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' }) : '—' },
                { label: 'Status', value: user?.is_active ? '✅ Ativa' : '❌ Inativa' },
              ].map(({ label, value }) => (
                <div key={label} style={{ padding: '16px 0', borderBottom: '1px solid rgba(255,255,255,0.06)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: '0.85rem', color: 'var(--color-text-2)', fontWeight: 500 }}>{label}</span>
                  <span style={{ fontWeight: 500 }}>{value || '—'}</span>
                </div>
              ))}
            </div>
          )}

          {/* Tab: Alterar Senha */}
          {tab === 'password' && (
            <form onSubmit={handleChangePassword}>
              <p style={{ fontSize: '0.88rem', color: 'var(--color-text-2)', marginBottom: '24px', lineHeight: 1.6 }}>
                Por segurança, confirme sua senha atual antes de definir uma nova.
              </p>

              <div className="form-group">
                <label className="form-label">Senha Atual</label>
                <input type="password" className="form-input" placeholder="Digite sua senha atual"
                  value={pwdForm.currentPassword}
                  onChange={e => setPwdForm({ ...pwdForm, currentPassword: e.target.value })}
                  required />
              </div>

              <div style={{ height: '1px', background: 'rgba(255,255,255,0.07)', margin: '20px 0' }} />

              <div className="form-group">
                <label className="form-label">Nova Senha</label>
                <input type="password" className="form-input" placeholder="Mín. 8 caracteres"
                  value={pwdForm.newPassword}
                  onChange={e => setPwdForm({ ...pwdForm, newPassword: e.target.value })}
                  required minLength={8} />
              </div>
              <div className="form-group">
                <label className="form-label">Confirmar Nova Senha</label>
                <input type="password" className="form-input" placeholder="Repita a nova senha"
                  value={pwdForm.confirm}
                  onChange={e => setPwdForm({ ...pwdForm, confirm: e.target.value })}
                  required minLength={8} />
              </div>

              {/* Indicador de força de senha */}
              {pwdForm.newPassword && (
                <div style={{ marginBottom: '16px' }}>
                  <div style={{ display: 'flex', gap: '4px', marginBottom: '6px' }}>
                    {[1, 2, 3, 4].map(i => {
                      const strength = [
                        pwdForm.newPassword.length >= 8,
                        /[A-Z]/.test(pwdForm.newPassword),
                        /[0-9]/.test(pwdForm.newPassword),
                        /[^A-Za-z0-9]/.test(pwdForm.newPassword),
                      ].filter(Boolean).length;
                      const colors = ['#ef4444', '#f97316', '#eab308', '#22c55e'];
                      return (
                        <div key={i} style={{
                          flex: 1, height: '4px', borderRadius: '2px',
                          background: i <= strength ? colors[strength - 1] : 'rgba(255,255,255,0.1)',
                          transition: 'background 0.3s',
                        }} />
                      );
                    })}
                  </div>
                  <span style={{ fontSize: '0.75rem', color: 'var(--color-text-2)' }}>
                    {[
                      pwdForm.newPassword.length >= 8,
                      /[A-Z]/.test(pwdForm.newPassword),
                      /[0-9]/.test(pwdForm.newPassword),
                      /[^A-Za-z0-9]/.test(pwdForm.newPassword),
                    ].filter(Boolean).length < 2 ? 'Fraca' :
                    [
                      pwdForm.newPassword.length >= 8,
                      /[A-Z]/.test(pwdForm.newPassword),
                      /[0-9]/.test(pwdForm.newPassword),
                      /[^A-Za-z0-9]/.test(pwdForm.newPassword),
                    ].filter(Boolean).length < 3 ? 'Média' :
                    [
                      pwdForm.newPassword.length >= 8,
                      /[A-Z]/.test(pwdForm.newPassword),
                      /[0-9]/.test(pwdForm.newPassword),
                      /[^A-Za-z0-9]/.test(pwdForm.newPassword),
                    ].filter(Boolean).length < 4 ? 'Boa' : 'Forte ✓'}
                  </span>
                </div>
              )}

              {pwdError && (
                <div style={{ padding: '12px 16px', borderRadius: '8px', background: 'rgba(239,68,68,0.12)',
                  color: 'var(--color-danger-light)', fontSize: '0.85rem', marginBottom: '16px', border: '1px solid rgba(239,68,68,0.2)' }}>
                  ⚠️ {pwdError}
                </div>
              )}
              {pwdSuccess && (
                <div style={{ padding: '12px 16px', borderRadius: '8px', background: 'rgba(34,197,94,0.12)',
                  color: 'var(--color-success-light)', fontSize: '0.85rem', marginBottom: '16px', border: '1px solid rgba(34,197,94,0.2)' }}>
                  ✅ {pwdSuccess}
                </div>
              )}

              <button type="submit" className="btn btn-primary btn-full" disabled={pwdSaving}
                style={{ marginTop: '8px', height: '46px', fontSize: '1rem' }}>
                {pwdSaving ? 'Salvando…' : '🔒 Alterar Senha'}
              </button>
            </form>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
