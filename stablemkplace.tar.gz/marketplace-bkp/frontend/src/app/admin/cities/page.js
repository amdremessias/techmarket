'use client';
import { useState, useEffect } from 'react';
import DashboardLayout from '../../dashboard/layout';
import api from '../../../lib/api';

export default function AdminCities() {
  const [cities, setCities] = useState([]);
  const [newCity, setNewCity] = useState({ name: '', state: 'SP' });

  useEffect(() => {
    loadCities();
  }, []);

  const loadCities = async () => {
    try {
      const res = await api.get('/cities').catch(() => ({ data: [] }));
      setCities(Array.isArray(res.data) ? res.data : []);
    } catch (err) {}
  };

  const handleAdd = async (e) => {
    e.preventDefault();
    try {
      await api.post('/cities', newCity);
      setNewCity({ name: '', state: 'SP' });
      loadCities();
    } catch (err) {
      alert('Erro ao adicionar cidade');
    }
  };

  return (
    <DashboardLayout>
      <div className="card-glass" style={{ padding: '32px' }}>
        <h2 style={{ fontSize: '1.5rem', marginBottom: '24px' }}>Gerenciar Cidades</h2>

        <form onSubmit={handleAdd} style={{ display: 'flex', gap: '16px', marginBottom: '32px' }}>
          <div style={{ flex: 2 }}>
            <label className="form-label">Nome da Cidade</label>
            <input 
              type="text" 
              className="form-input" 
              placeholder="ex: São José dos Campos" 
              value={newCity.name}
              onChange={(e) => setNewCity({ ...newCity, name: e.target.value })}
              required
            />
          </div>
          <div style={{ flex: 1 }}>
            <label className="form-label">UF</label>
            <input 
              type="text" 
              className="form-input" 
              maxLength="2"
              placeholder="SP" 
              value={newCity.state}
              onChange={(e) => setNewCity({ ...newCity, state: e.target.value.toUpperCase() })}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary" style={{ alignSelf: 'flex-end', height: '42px' }}>Adicionar</button>
        </form>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '16px' }}>
          {cities.length > 0 ? cities.map((city) => (
            <div key={city.id} className="card-glass" style={{ padding: '16px', background: 'rgba(255,255,255,0.02)' }}>
              <h4 style={{ marginBottom: '4px' }}>{city.name}</h4>
              <p style={{ fontSize: '0.8rem', color: 'var(--color-text-2)' }}>Estado: {city.state}</p>
            </div>
          )) : (
            <p style={{ gridColumn: '1 / -1', textAlign: 'center', color: 'var(--color-text-2)', padding: '40px' }}>Nenhuma cidade cadastrada.</p>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
