'use client';
import { useState, useEffect } from 'react';
import DashboardLayout from '../dashboard/layout';
import api from '../../lib/api';

export default function AdminDashboard() {
  const [stats, setStats] = useState({ totalUsers: 0, totalQuotes: 0, revenue: 'R$ 0,00' });
  const [quotes, setQuotes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [quotesRes, usersRes] = await Promise.all([
        api.get('/quotes'),
        api.get('/users')
      ]);
      
      const allQuotes = quotesRes.data || [];
      setQuotes(allQuotes);
      setStats({
        totalUsers: usersRes.data?.length || 0,
        totalQuotes: allQuotes.length,
        revenue: `R$ ${(allQuotes.length * 15.5).toFixed(2).replace('.', ',')}` // Simulação de taxa
      });
    } catch (err) {
      console.error('Erro ao carregar dados admin');
    } finally {
      setLoading(false);
    }
  };

  return (
    <DashboardLayout>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '24px' }}>
        <div className="card-glass" style={{ padding: '24px' }}>
          <h3 style={{ fontSize: '0.9rem', color: 'var(--color-text-2)', marginBottom: '8px' }}>Usuários Totais</h3>
          <p style={{ fontSize: '2rem', fontWeight: 700 }}>{stats.totalUsers}</p>
        </div>
        <div className="card-glass" style={{ padding: '24px' }}>
          <h3 style={{ fontSize: '0.9rem', color: 'var(--color-text-2)', marginBottom: '8px' }}>Cotações Realizadas</h3>
          <p style={{ fontSize: '2rem', fontWeight: 700 }}>{stats.totalQuotes}</p>
        </div>
        <div className="card-glass" style={{ padding: '24px' }}>
          <h3 style={{ fontSize: '0.9rem', color: 'var(--color-text-2)', marginBottom: '8px' }}>Receita Estimada</h3>
          <p style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--color-primary-light)' }}>{stats.revenue}</p>
        </div>

        <div className="card-glass" style={{ gridColumn: '1 / -1', padding: '32px', marginTop: '16px' }}>
          <h3 style={{ fontSize: '1.25rem', marginBottom: '24px' }}>Todas as Requisições de Clientes</h3>
          
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ textAlign: 'left', borderBottom: '1px solid var(--color-border)' }}>
                  <th style={{ padding: '12px' }}>Data</th>
                  <th style={{ padding: '12px' }}>Cliente</th>
                  <th style={{ padding: '12px' }}>Serviço</th>
                  <th style={{ padding: '12px' }}>Técnico</th>
                  <th style={{ padding: '12px' }}>Status</th>
                  <th style={{ padding: '12px' }}>Valor</th>
                </tr>
              </thead>
              <tbody>
                {quotes.map((quote) => (
                  <tr key={quote.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.05)', fontSize: '0.9rem' }}>
                    <td style={{ padding: '12px' }}>{new Date(quote.created_at).toLocaleDateString('pt-BR')}</td>
                    <td style={{ padding: '12px' }}>
                      <div style={{ fontWeight: 600 }}>{quote.client_name}</div>
                      <div style={{ fontSize: '0.7rem', color: 'var(--color-text-2)' }}>{quote.client_email}</div>
                    </td>
                    <td style={{ padding: '12px' }}>
                      <span>{quote.category_icon} {quote.category_name}</span>
                    </td>
                    <td style={{ padding: '12px' }}>
                      {quote.provider_name ? (
                        <div style={{ color: 'var(--color-primary-light)' }}>{quote.provider_name}</div>
                      ) : (
                        <span style={{ color: 'var(--color-text-2)', fontStyle: 'italic' }}>Aguardando...</span>
                      )}
                    </td>
                    <td style={{ padding: '12px' }}>
                      <span style={{ 
                        padding: '4px 8px', borderRadius: '4px', background: 'rgba(255,255,255,0.05)', fontSize: '0.75rem' 
                      }}>
                        {quote.status}
                      </span>
                    </td>
                    <td style={{ padding: '12px', fontWeight: 600 }}>
                      {quote.proposed_value ? `R$ ${quote.proposed_value}` : '---'}
                    </td>
                  </tr>
                ))}
                {quotes.length === 0 && !loading && (
                  <tr>
                    <td colSpan="6" style={{ padding: '40px', textAlign: 'center', color: 'var(--color-text-2)' }}>
                      Nenhuma cotação encontrada no sistema.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
