'use client';
import { useEffect, useState } from 'react';
import DashboardLayout from '../../dashboard/layout';
import api from '../../../lib/api';

const EMPTY_CATEGORY = { name: '', icon: 'tool', description: '', is_active: true };

export default function AdminCategories() {
  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState(EMPTY_CATEGORY);
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');

  useEffect(() => { loadCategories(); }, []);

  const loadCategories = async () => {
    setLoading(true);
    try {
      const res = await api.get('/services');
      setCategories(Array.isArray(res.data) ? res.data : []);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setEditingId(null);
    setForm(EMPTY_CATEGORY);
    setMessage('');
  };

  const editCategory = (cat) => {
    setEditingId(cat.id);
    setForm({
      name: cat.name || '',
      icon: cat.icon || 'tool',
      description: cat.description || '',
      is_active: !!cat.is_active,
    });
    setMessage('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');
    try {
      if (editingId) {
        await api.put(`/services/${editingId}`, form);
      } else {
        await api.post('/services', form);
      }
      resetForm();
      loadCategories();
    } catch (err) {
      setMessage(err.response?.data?.message || 'Erro ao salvar categoria');
    }
  };

  const handleToggle = async (id) => {
    try {
      await api.patch(`/services/${id}/toggle`);
      loadCategories();
    } catch {
      setMessage('Erro ao atualizar status da categoria');
    }
  };

  return (
    <DashboardLayout>
      <section className="card-glass" style={{ padding: '28px', marginBottom: '24px' }}>
        <h2 style={{ fontSize: '1.35rem', marginBottom: '6px' }}>Categorias de servicos</h2>
        <p style={{ color: 'var(--color-text-2)', fontSize: '0.9rem', marginBottom: '22px' }}>
          Cadastre, edite e ative os grupos de categoria usados pelos tecnicos.
        </p>

        <form onSubmit={handleSubmit}>
          <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 0.7fr', gap: '14px' }}>
            <div className="form-group">
              <label className="form-label">Nome</label>
              <input className="form-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
            </div>
            <div className="form-group">
              <label className="form-label">Icone</label>
              <input className="form-input" value={form.icon} onChange={(e) => setForm({ ...form, icon: e.target.value })} placeholder="tool" />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Descricao</label>
            <textarea className="form-input" rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </div>
          <label style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', marginBottom: '18px' }}>
            <input type="checkbox" checked={form.is_active} onChange={(e) => setForm({ ...form, is_active: e.target.checked })} />
            Categoria ativa
          </label>
          {message && <p style={{ color: 'var(--color-danger-light)', marginBottom: '14px' }}>{message}</p>}
          <div style={{ display: 'flex', gap: '10px' }}>
            <button type="submit" className="btn btn-primary">{editingId ? 'Salvar categoria' : 'Adicionar categoria'}</button>
            {editingId && <button type="button" className="btn" onClick={resetForm}>Cancelar edicao</button>}
          </div>
        </form>
      </section>

      <section className="card-glass" style={{ padding: '28px' }}>
        {loading ? (
          <p style={{ textAlign: 'center', color: 'var(--color-text-2)', padding: '36px' }}>Carregando...</p>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: '14px' }}>
            {categories.map((cat) => (
              <div key={cat.id} style={{ border: '1px solid var(--color-border)', borderRadius: '8px', padding: '16px', background: 'rgba(255,255,255,0.02)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: '12px' }}>
                  <div>
                    <h3 style={{ fontSize: '1rem', marginBottom: '4px' }}>{cat.name}</h3>
                    <p style={{ color: 'var(--color-text-2)', fontSize: '0.82rem', minHeight: '38px' }}>{cat.description || 'Sem descricao'}</p>
                    <p style={{ color: cat.is_active ? 'var(--color-success-light)' : 'var(--color-danger-light)', fontSize: '0.82rem', marginTop: '8px' }}>
                      {cat.is_active ? 'Ativa' : 'Inativa'}
                    </p>
                  </div>
                  <span style={{ color: 'var(--color-text-2)', fontSize: '0.8rem' }}>{cat.icon}</span>
                </div>
                <div style={{ display: 'flex', gap: '8px', marginTop: '16px' }}>
                  <button className="btn" onClick={() => editCategory(cat)} style={{ padding: '6px 10px' }}>Editar</button>
                  <button className="btn" onClick={() => handleToggle(cat.id)} style={{ padding: '6px 10px' }}>
                    {cat.is_active ? 'Desativar' : 'Ativar'}
                  </button>
                </div>
              </div>
            ))}
            {categories.length === 0 && (
              <p style={{ gridColumn: '1 / -1', textAlign: 'center', color: 'var(--color-text-2)', padding: '40px' }}>
                Nenhuma categoria cadastrada.
              </p>
            )}
          </div>
        )}
      </section>
    </DashboardLayout>
  );
}
