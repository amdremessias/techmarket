'use client';
import { useEffect, useState } from 'react';
import DashboardLayout from '../../dashboard/layout';
import api from '../../../lib/api';

const EMPTY_USER = {
  name: '',
  email: '',
  password: '',
  role: 'client',
  phone: '',
  plan: 'FREE',
  subscriptionStatus: 'INACTIVE',
  isActive: true,
  emailVerified: true,
  technicianLevel: 'junior',
  categoryIds: [],
};

const ROLE_LABEL = { admin: 'Admin', provider: 'Tecnico', client: 'Cliente' };
const LEVEL_LABEL = { junior: 'Junior', pleno: 'Pleno', senior: 'Senior', especialista: 'Especialista' };

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(null);
  const [form, setForm] = useState(EMPTY_USER);
  const [message, setMessage] = useState('');

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [usersRes, catsRes] = await Promise.all([api.get('/users'), api.get('/services')]);
      setUsers(Array.isArray(usersRes.data) ? usersRes.data : []);
      setCategories(Array.isArray(catsRes.data) ? catsRes.data : []);
    } finally {
      setLoading(false);
    }
  };

  const openCreate = () => {
    setForm(EMPTY_USER);
    setMessage('');
    setModal('create');
  };

  const openEdit = (user) => {
    setForm({
      id: user.id,
      name: user.name || '',
      email: user.email || '',
      password: '',
      role: user.role || 'client',
      phone: user.phone || '',
      plan: user.plan || 'FREE',
      subscriptionStatus: user.subscription_status || 'INACTIVE',
      isActive: !!user.is_active,
      emailVerified: !!user.email_verified,
      technicianLevel: user.technician_level || 'junior',
      categoryIds: user.services || [],
    });
    setMessage('');
    setModal('edit');
  };

  const openPassword = (user) => {
    setForm({ ...EMPTY_USER, id: user.id, name: user.name, email: user.email, password: '' });
    setMessage('');
    setModal('password');
  };

  const closeModal = () => {
    setModal(null);
    setMessage('');
  };

  const setField = (key, value) => {
    setForm((current) => ({
      ...current,
      [key]: value,
      categoryIds: key === 'role' && value !== 'provider' ? [] : current.categoryIds,
    }));
  };

  const toggleCategory = (id) => {
    setForm((current) => ({
      ...current,
      categoryIds: current.categoryIds.includes(id)
        ? current.categoryIds.filter((item) => item !== id)
        : [...current.categoryIds, id],
    }));
  };

  const saveUser = async (e) => {
    e.preventDefault();
    setMessage('');
    if (form.role === 'provider' && form.categoryIds.length === 0) {
      setMessage('Selecione ao menos uma categoria para o tecnico.');
      return;
    }

    try {
      const payload = {
        name: form.name,
        email: form.email,
        role: form.role,
        phone: form.phone || null,
        plan: form.plan,
        subscriptionStatus: form.subscriptionStatus,
        isActive: form.isActive,
        emailVerified: form.emailVerified,
        technicianLevel: form.role === 'provider' ? form.technicianLevel : null,
        categoryIds: form.role === 'provider' ? form.categoryIds : [],
      };

      if (modal === 'create') {
        await api.post('/users', { ...payload, password: form.password });
      } else {
        await api.put(`/users/${form.id}`, payload);
      }

      closeModal();
      loadData();
    } catch (err) {
      setMessage(err.response?.data?.message || 'Erro ao salvar usuario.');
    }
  };

  const savePassword = async (e) => {
    e.preventDefault();
    setMessage('');
    try {
      await api.patch(`/users/${form.id}/password`, { newPassword: form.password });
      setMessage('Senha alterada com sucesso.');
      setForm((current) => ({ ...current, password: '' }));
    } catch (err) {
      setMessage(err.response?.data?.message || 'Erro ao alterar senha.');
    }
  };

  const toggleActive = async (user) => {
    try {
      await api.patch(`/users/${user.id}/toggle-active`);
      loadData();
    } catch {
      alert('Erro ao alterar status do usuario');
    }
  };

  return (
    <DashboardLayout>
      <section className="card-glass" style={{ padding: '28px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
          <div>
            <h2 style={{ fontSize: '1.35rem', marginBottom: '4px' }}>Usuarios e clientes</h2>
            <p style={{ color: 'var(--color-text-2)', fontSize: '0.9rem' }}>Edite perfis, status, planos, niveis tecnicos e categorias.</p>
          </div>
          <button onClick={openCreate} className="btn btn-primary">Novo usuario</button>
        </div>

        {loading ? (
          <p style={{ padding: '36px', textAlign: 'center', color: 'var(--color-text-2)' }}>Carregando...</p>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ textAlign: 'left', borderBottom: '1px solid var(--color-border)' }}>
                  {['Nome', 'E-mail', 'Tipo', 'Nivel', 'Categorias', 'Status', 'Acoes'].map((heading) => (
                    <th key={heading} style={{ padding: '12px', fontSize: '0.78rem', color: 'var(--color-text-2)', textTransform: 'uppercase' }}>{heading}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                    <td style={{ padding: '12px', fontWeight: 700 }}>{user.name}</td>
                    <td style={{ padding: '12px', color: 'var(--color-text-2)', fontSize: '0.9rem' }}>{user.email}</td>
                    <td style={{ padding: '12px' }}>{ROLE_LABEL[user.role] || user.role}</td>
                    <td style={{ padding: '12px' }}>{user.role === 'provider' ? (LEVEL_LABEL[user.technician_level] || 'Junior') : '-'}</td>
                    <td style={{ padding: '12px', maxWidth: '260px', color: 'var(--color-text-2)', fontSize: '0.86rem' }}>
                      {user.role === 'provider' ? (user.service_names?.join(', ') || 'Sem categorias') : '-'}
                    </td>
                    <td style={{ padding: '12px' }}>
                      <span style={{ color: user.is_active ? 'var(--color-success-light)' : 'var(--color-danger-light)' }}>
                        {user.is_active ? 'Ativo' : 'Inativo'}
                      </span>
                    </td>
                    <td style={{ padding: '12px' }}>
                      <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                        <button className="btn" onClick={() => openEdit(user)} style={{ padding: '6px 10px' }}>Editar</button>
                        <button className="btn" onClick={() => openPassword(user)} style={{ padding: '6px 10px' }}>Senha</button>
                        <button className="btn" onClick={() => toggleActive(user)} style={{ padding: '6px 10px' }}>
                          {user.is_active ? 'Desativar' : 'Ativar'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {(modal === 'create' || modal === 'edit') && (
        <UserModal
          title={modal === 'create' ? 'Criar usuario' : 'Editar usuario'}
          form={form}
          categories={categories}
          message={message}
          setField={setField}
          toggleCategory={toggleCategory}
          onSubmit={saveUser}
          onClose={closeModal}
          requirePassword={modal === 'create'}
        />
      )}

      {modal === 'password' && (
        <div style={overlayStyle} onClick={closeModal}>
          <div style={modalStyle} onClick={(e) => e.stopPropagation()}>
            <h3 style={{ marginBottom: '4px' }}>Alterar senha</h3>
            <p style={{ color: 'var(--color-text-2)', fontSize: '0.85rem', marginBottom: '20px' }}>{form.name} - {form.email}</p>
            <form onSubmit={savePassword}>
              <label className="form-label">Nova senha</label>
              <input className="form-input" type="password" minLength={8} required value={form.password} onChange={(e) => setField('password', e.target.value)} />
              {message && <p style={{ marginTop: '12px', color: message.includes('sucesso') ? 'var(--color-success-light)' : 'var(--color-danger-light)' }}>{message}</p>}
              <div style={{ display: 'flex', gap: '10px', marginTop: '22px' }}>
                <button className="btn btn-primary btn-full" type="submit">Salvar</button>
                <button className="btn btn-full" type="button" onClick={closeModal}>Fechar</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}

function UserModal({ title, form, categories, message, setField, toggleCategory, onSubmit, onClose, requirePassword }) {
  return (
    <div style={overlayStyle} onClick={onClose}>
      <div style={{ ...modalStyle, width: '680px', maxHeight: '90vh', overflowY: 'auto' }} onClick={(e) => e.stopPropagation()}>
        <h3 style={{ marginBottom: '20px' }}>{title}</h3>
        <form onSubmit={onSubmit}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
            <Field label="Nome"><input className="form-input" required value={form.name} onChange={(e) => setField('name', e.target.value)} /></Field>
            <Field label="E-mail"><input className="form-input" type="email" required value={form.email} onChange={(e) => setField('email', e.target.value)} /></Field>
            {requirePassword && <Field label="Senha"><input className="form-input" type="password" minLength={8} required value={form.password} onChange={(e) => setField('password', e.target.value)} /></Field>}
            <Field label="Telefone"><input className="form-input" value={form.phone} onChange={(e) => setField('phone', e.target.value)} /></Field>
            <Field label="Tipo">
              <select className="form-input" value={form.role} onChange={(e) => setField('role', e.target.value)}>
                <option value="client">Cliente</option>
                <option value="provider">Tecnico</option>
                <option value="admin">Administrador</option>
              </select>
            </Field>
            <Field label="Plano">
              <select className="form-input" value={form.plan} onChange={(e) => setField('plan', e.target.value)}>
                <option value="FREE">Free</option>
                <option value="PREMIUM_PROVIDER">Premium tecnico</option>
                <option value="PREMIUM_CLIENT">Premium cliente</option>
              </select>
            </Field>
            <Field label="Assinatura">
              <select className="form-input" value={form.subscriptionStatus} onChange={(e) => setField('subscriptionStatus', e.target.value)}>
                <option value="INACTIVE">Inativa</option>
                <option value="ACTIVE">Ativa</option>
                <option value="CANCELLED">Cancelada</option>
                <option value="EXPIRED">Expirada</option>
              </select>
            </Field>
            {form.role === 'provider' && (
              <Field label="Nivel tecnico">
                <select className="form-input" value={form.technicianLevel} onChange={(e) => setField('technicianLevel', e.target.value)}>
                  <option value="junior">Junior</option>
                  <option value="pleno">Pleno</option>
                  <option value="senior">Senior</option>
                  <option value="especialista">Especialista</option>
                </select>
              </Field>
            )}
          </div>

          <div style={{ display: 'flex', gap: '18px', marginTop: '8px', marginBottom: '18px' }}>
            <label><input type="checkbox" checked={form.isActive} onChange={(e) => setField('isActive', e.target.checked)} /> Ativo</label>
            <label><input type="checkbox" checked={form.emailVerified} onChange={(e) => setField('emailVerified', e.target.checked)} /> E-mail verificado</label>
          </div>

          {form.role === 'provider' && (
            <div style={{ marginTop: '10px' }}>
              <label className="form-label">Categorias de atuacao</label>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))', gap: '8px' }}>
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => toggleCategory(cat.id)}
                    style={{
                      padding: '10px',
                      borderRadius: '8px',
                      border: form.categoryIds.includes(cat.id) ? '1px solid var(--color-primary)' : '1px solid var(--color-border)',
                      background: form.categoryIds.includes(cat.id) ? 'rgba(99,102,241,0.12)' : 'transparent',
                      color: cat.is_active ? 'var(--color-text)' : 'var(--color-text-3)',
                      cursor: 'pointer',
                      textAlign: 'left',
                    }}
                  >
                    {cat.name}{cat.is_active ? '' : ' (inativa)'}
                  </button>
                ))}
              </div>
            </div>
          )}

          {message && <p style={{ marginTop: '14px', color: 'var(--color-danger-light)' }}>{message}</p>}
          <div style={{ display: 'flex', gap: '10px', marginTop: '24px' }}>
            <button className="btn btn-primary btn-full" type="submit">Salvar</button>
            <button className="btn btn-full" type="button" onClick={onClose}>Cancelar</button>
          </div>
        </form>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div className="form-group">
      <label className="form-label">{label}</label>
      {children}
    </div>
  );
}

const overlayStyle = {
  position: 'fixed',
  inset: 0,
  background: 'rgba(0,0,0,0.78)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  zIndex: 1000,
  padding: '24px',
};

const modalStyle = {
  width: '440px',
  padding: '28px',
  background: 'var(--color-surface, rgba(30,30,50,0.98))',
  border: '1px solid var(--color-border)',
  borderRadius: '12px',
};
