-- Setup script for local PostgreSQL development
-- Connect to PostgreSQL as superuser first: psql -U postgres

-- Create database
CREATE DATABASE marketplace;

-- Connect to marketplace database
\c marketplace;

-- Create marketplace_user with password
CREATE USER marketplace_user WITH PASSWORD 'marketplace_password_123!';

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE marketplace TO marketplace_user;

-- Run the init script
\i database/init.sql;

-- Grant privileges on all tables to marketplace_user
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO marketplace_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO marketplace_user;

-- Verify connection
SELECT 'Database setup complete!' AS status;