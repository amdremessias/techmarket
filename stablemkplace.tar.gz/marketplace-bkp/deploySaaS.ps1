#===============================================================================
# DEPLOY LOCAL - MARKETPLACE DE SERVIÇOS
#===============================================================================
Write-Host "🚀 INICIANDO DEPLOY LOCAL..." -ForegroundColor Cyan
Write-Host ""
# Passo 1: Verificar pré-requisitos
Write-Host "==========================================" -ForegroundColor Yellow
Write-Host "PASSO 1: VERIFICANDO PRÉ-REQUISITOS" -ForegroundColor Yellow
Write-Host "==========================================" -ForegroundColor Yellow
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    Write-Host "❌ ERRO: Node.js não instalado!" -ForegroundColor Red
    Write-Host "   Instale em: https://nodejs.org" -ForegroundColor Yellow
    exit 1
}
Write-Host "✅ Node.js: $(node --version)" -ForegroundColor Green
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
    Write-Host "❌ ERRO: npm não instalado!" -ForegroundColor Red
    exit 1
}
Write-Host "✅ npm: $(npm --version)" -ForegroundColor Green
# Passo 2: Aplicar fix no database.js
Write-Host ""
Write-Host "==========================================" -ForegroundColor Yellow
Write-Host "PASSO 2: APLICANDO FIX NO BANCO DE DADOS" -ForegroundColor Yellow
Write-Host "==========================================" -ForegroundColor Yellow
$dbFile = Join-Path $PSScriptRoot "backend\src\config\database.js"
$content = Get-Content $dbFile -Raw
if ($content -notmatch "host: process\.env\.DB_HOST") {
    Write-Host "🔧 Aplicando correção..." -ForegroundColor Yellow
    
    $fixedContent = @"
require('dotenv').config({ path: require('path').resolve(__dirname, '../../../.env') });
const { Pool } = require('pg');
const logger = require('./logger');
const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT) || 5432,
  database: process.env.DB_NAME || 'marketplace',
  user: process.env.DB_USER || 'marketplace_user',
  password: process.env.DB_PASSWORD,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});
pool.on('error', (err) => {
  logger.error('Unexpected PostgreSQL pool error', { error: err.message });
});
pool.query('SELECT NOW()')
  .then(() => logger.info('✅ PostgreSQL conectado com sucesso'))
  .catch((err) => {
    logger.error('❌ Falha ao conectar ao PostgreSQL', { error: err.message });
    process.exit(1);
  });
const query = async (text, params) => {
  const start = Date.now();
  try {
    const result = await pool.query(text, params);
    const duration = Date.now() - start;
    if (process.env.NODE_ENV === 'development') {
      logger.debug('Query executada', { text, duration, rows: result.rowCount });
    }
    return result;
  } catch (err) {
    logger.error('Erro na query SQL', { text, error: err.message });
    throw err;
  }
};
module.exports = { pool, query };
"@
    Set-Content -Path $dbFile -Value $fixedContent -NoNewline -Encoding UTF8
    Write-Host "✅ Arquivo database.js corrigido!" -ForegroundColor Green
} else {
    Write-Host "ℹ️  Arquivo já está corrigido" -ForegroundColor Cyan
}
# Passo 3: Instalar dependências
Write-Host ""
Write-Host "==========================================" -ForegroundColor Yellow
Write-Host "PASSO 3: INSTALANDO DEPENDÊNCIAS" -ForegroundColor Yellow
Write-Host "==========================================" -ForegroundColor Yellow
Set-Location "backend"
Write-Host "📦 Instalando backend..." -ForegroundColor Yellow
npm install
Set-Location ".."
Set-Location "frontend"
Write-Host "📦 Instalando frontend..." -ForegroundColor Yellow
npm install
Set-Location ".."
Write-Host "✅ Dependências instaladas!" -ForegroundColor Green
# Passo 4: Configurar .env se necessário
Write-Host ""
Write-Host "==========================================" -ForegroundColor Yellow
Write-Host "PASSO 4: CONFIGURANDO AMBIENTE" -ForegroundColor Yellow
Write-Host "==========================================" -ForegroundColor Yellow
if (-not (Test-Path "backend\.env")) {
    Write-Host "📝 Criando backend/.env..." -ForegroundColor Yellow
    $envContent = @"
NODE_ENV=development
PORT=4000
DB_HOST=localhost
DB_PORT=5432
DB_NAME=marketplace
DB_USER=marketplace_user
DB_PASSWORD=marketplace_password_123!
"@
    Set-Content "backend\.env" $envContent -NoNewline
    Write-Host "✅ backend/.env criado!" -ForegroundColor Green
} else {
    Write-Host "ℹ️  backend/.env já existe" -ForegroundColor Cyan
}
# Passo 5: Iniciar servidor
Write-Host ""
Write-Host "==========================================" -ForegroundColor Yellow
Write-Host "PASSO 5: INICIANDO BACKEND" -ForegroundColor Yellow
Write-Host "==========================================" -ForegroundColor Yellow
Set-Location "backend"
Write-Host "🚀 Iniciando servidor em http://localhost:4000..." -ForegroundColor Green
npm run dev
</parameter>
<parameter=description>
Script PowerShell para deploy local
</parameter>
</function>
</tool_call>