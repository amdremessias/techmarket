-- ============================================================
-- SEED.SQL — Categorias iniciais de serviço
-- ============================================================

INSERT INTO service_categories (id, name, slug, description, icon, is_active) VALUES
  (uuid_generate_v4(), 'Redes e Infraestrutura', 'redes-infraestrutura', 'Instalação e configuração de redes cabeadas e sem fio, switches, roteadores e infraestrutura de TI', 'network-wired', true),
  (uuid_generate_v4(), 'CFTV e Segurança', 'cftv-seguranca', 'Instalação e manutenção de câmeras de segurança, sistemas DVR/NVR e alarmes', 'camera', true),
  (uuid_generate_v4(), 'Suporte de TI', 'suporte-ti', 'Manutenção de computadores, formatação, instalação de software e suporte técnico geral', 'laptop', true),
  (uuid_generate_v4(), 'Fibra Óptica', 'fibra-optica', 'Instalação, fusão e certificação de cabos de fibra óptica', 'zap', true),
  (uuid_generate_v4(), 'Cabeamento Estruturado', 'cabeamento-estruturado', 'Projeto e instalação de cabeamento lógico e elétrico estruturado', 'cable', true),
  (uuid_generate_v4(), 'Servidores e Cloud', 'servidores-cloud', 'Configuração de servidores físicos, virtualização e serviços em nuvem', 'server', true),
  (uuid_generate_v4(), 'Automação Residencial', 'automacao-residencial', 'Instalação de sistemas smart home, controle de acesso e automação predial', 'home', true),
  (uuid_generate_v4(), 'Energia Solar', 'energia-solar', 'Instalação e manutenção de painéis fotovoltaicos e sistemas de energia solar', 'sun', true),
  (uuid_generate_v4(), 'Elétrica Industrial', 'eletrica-industrial', 'Serviços elétricos industriais, quadros de distribuição e SPDA', 'zap-off', true),
  (uuid_generate_v4(), 'Telecomunicações', 'telecomunicacoes', 'Instalação de ramais, PABX, telefonia VoIP e links de internet', 'phone', true),
  (uuid_generate_v4(), 'Ar Condicionado', 'ar-condicionado', 'Instalação, manutenção e limpeza de sistemas de climatização', 'wind', true),
  (uuid_generate_v4(), 'CFTV Analógico (Legado)', 'cftv-analogico', 'Manutenção e upgrade de sistemas analógicos de videomonitoramento', 'video', true)
ON CONFLICT (slug) DO NOTHING;

-- ============================================================
-- Usuário de demonstração: Cliente
-- Senha: Client@123456
-- ============================================================
INSERT INTO users (name, email, password_hash, role, is_active, email_verified, plan) VALUES (
  'Cliente Demo',
  'cliente@demo.local',
  '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewPbpxVFQv8Ul.Hq',
  'client',
  true,
  true,
  'FREE'
) ON CONFLICT (email) DO NOTHING;

-- ============================================================
-- Usuário de demonstração: Prestador (São Paulo - Paulista)
-- Senha: Provider@123456
-- ============================================================
INSERT INTO users (name, email, password_hash, role, phone, is_active, email_verified, plan, location) VALUES (
  'Técnico Demo',
  'tecnico@demo.local',
  '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewPbpxVFQv8Ul.Hq',
  'provider',
  '11999999999',
  true,
  true,
  'PREMIUM_PROVIDER',
  ST_SetSRID(ST_MakePoint(-46.6395, -23.5614), 4326)  -- Av. Paulista, SP
) ON CONFLICT (email) DO NOTHING;

-- Associa o técnico demo à categoria de Redes e CFTV
INSERT INTO provider_categories (user_id, category_id)
SELECT 
  u.id,
  sc.id
FROM users u, service_categories sc
WHERE u.email = 'tecnico@demo.local'
  AND sc.slug IN ('redes-infraestrutura', 'cftv-seguranca', 'suporte-ti')
ON CONFLICT DO NOTHING;
