-- ============================================================
-- INIT.SQL — Schema completo do Marketplace de Serviços
-- PostgreSQL 15 + PostGIS 3.x
-- ============================================================

-- Habilita extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pg_trgm;  -- Para busca textual por similaridade

-- ── ENUM: Roles de usuário ────────────────────────────────────────────────────
CREATE TYPE user_role AS ENUM ('client', 'provider', 'admin');

-- ── ENUM: Planos ─────────────────────────────────────────────────────────────
CREATE TYPE subscription_plan AS ENUM ('FREE', 'PREMIUM_PROVIDER', 'PREMIUM_CLIENT');

-- ── ENUM: Status de assinatura ────────────────────────────────────────────────
CREATE TYPE subscription_status AS ENUM ('ACTIVE', 'INACTIVE', 'CANCELLED', 'EXPIRED');

-- ── ENUM: Status de orçamento ────────────────────────────────────────────────
CREATE TYPE quote_status AS ENUM (
  'PENDING', 'PAID', 'MATCHED', 'QUOTED', 'ACCEPTED',
  'IN_PROGRESS', 'OTP_PENDING', 'COMPLETED', 'CANCELLED', 'DISPUTED'
);

-- ============================================================
-- TABELA: users
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
  id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name                    VARCHAR(100) NOT NULL,
  email                   VARCHAR(255) NOT NULL UNIQUE,
  password_hash           VARCHAR(255) NOT NULL,
  role                    user_role NOT NULL DEFAULT 'client',
  phone                   VARCHAR(20),
  avatar_url              TEXT,
  plan                    subscription_plan NOT NULL DEFAULT 'FREE',
  subscription_status     subscription_status DEFAULT 'INACTIVE',
  subscription_expires_at TIMESTAMP WITH TIME ZONE,
  -- Localização geográfica (PostGIS) — SRID 4326 = WGS84 (GPS)
  location                GEOMETRY(Point, 4326),
  is_active               BOOLEAN NOT NULL DEFAULT true,
  email_verified          BOOLEAN NOT NULL DEFAULT false,
  created_at              TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at              TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Índice geoespacial para queries PostGIS (GIST = otimizado para dados geográficos)
CREATE INDEX IF NOT EXISTS idx_users_location ON users USING GIST(location);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_active ON users(is_active) WHERE is_active = true;

-- ============================================================
-- TABELA: service_categories
-- ============================================================
CREATE TABLE IF NOT EXISTS service_categories (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name        VARCHAR(100) NOT NULL,
  slug        VARCHAR(100) NOT NULL UNIQUE,
  description TEXT,
  icon        VARCHAR(50),     -- Nome do ícone (ex: 'wifi', 'camera', 'server')
  is_active   BOOLEAN NOT NULL DEFAULT true,
  created_at  TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TABELA: provider_categories (Many-to-Many: providers <-> categorias)
-- ============================================================
CREATE TABLE IF NOT EXISTS provider_categories (
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category_id UUID NOT NULL REFERENCES service_categories(id) ON DELETE CASCADE,
  created_at  TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  PRIMARY KEY (user_id, category_id)
);

-- ============================================================
-- TABELA: quotes (Orçamentos)
-- ============================================================
CREATE TABLE IF NOT EXISTS quotes (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id       UUID NOT NULL REFERENCES users(id),
  provider_id     UUID REFERENCES users(id),
  category_id     UUID NOT NULL REFERENCES service_categories(id),
  status          quote_status NOT NULL DEFAULT 'PENDING',
  description     TEXT NOT NULL,
  address         TEXT,
  location        GEOMETRY(Point, 4326),
  proposed_value  DECIMAL(10, 2),              -- Valor proposto pelo prestador
  payment_id      VARCHAR(255),                -- ID do pagamento no MP
  completed_at    TIMESTAMP WITH TIME ZONE,
  created_at      TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_quotes_client ON quotes(client_id);
CREATE INDEX IF NOT EXISTS idx_quotes_provider ON quotes(provider_id);
CREATE INDEX IF NOT EXISTS idx_quotes_status ON quotes(status);
CREATE INDEX IF NOT EXISTS idx_quotes_location ON quotes USING GIST(location);
CREATE INDEX IF NOT EXISTS idx_quotes_created ON quotes(created_at DESC);

-- ============================================================
-- TABELA: quote_status_log (Auditoria de mudanças de status)
-- ============================================================
CREATE TABLE IF NOT EXISTS quote_status_log (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  quote_id    UUID NOT NULL REFERENCES quotes(id) ON DELETE CASCADE,
  old_status  quote_status,
  new_status  quote_status NOT NULL,
  changed_by  UUID REFERENCES users(id),
  created_at  TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_status_log_quote ON quote_status_log(quote_id);

-- ============================================================
-- TABELA: messages (Chat interno)
-- ============================================================
CREATE TABLE IF NOT EXISTS messages (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  quote_id    UUID NOT NULL REFERENCES quotes(id) ON DELETE CASCADE,
  sender_id   UUID NOT NULL REFERENCES users(id),
  content     TEXT NOT NULL,
  read_at     TIMESTAMP WITH TIME ZONE,
  created_at  TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_messages_quote ON messages(quote_id);
CREATE INDEX IF NOT EXISTS idx_messages_created ON messages(created_at DESC);

-- ============================================================
-- TABELA: otp_tokens
-- ============================================================
CREATE TABLE IF NOT EXISTS otp_tokens (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  quote_id    UUID NOT NULL UNIQUE REFERENCES quotes(id) ON DELETE CASCADE,
  token_hash  VARCHAR(255) NOT NULL,
  expires_at  TIMESTAMP WITH TIME ZONE NOT NULL,
  attempts    INTEGER NOT NULL DEFAULT 0,
  created_at  TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TABELA: reviews (Avaliações)
-- ============================================================
CREATE TABLE IF NOT EXISTS reviews (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  quote_id    UUID NOT NULL UNIQUE REFERENCES quotes(id),
  client_id   UUID NOT NULL REFERENCES users(id),
  provider_id UUID NOT NULL REFERENCES users(id),
  rating      SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment     TEXT,
  created_at  TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_reviews_provider ON reviews(provider_id);

-- ============================================================
-- TABELA: audit_logs (Logs de auditoria de segurança)
-- ============================================================
CREATE TABLE IF NOT EXISTS audit_logs (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID REFERENCES users(id) ON DELETE SET NULL,
  action      VARCHAR(100) NOT NULL,
  entity      VARCHAR(100) NOT NULL,
  entity_id   VARCHAR(255),
  old_value   JSONB,
  new_value   JSONB,
  ip_address  INET,
  created_at  TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs(entity, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC);

-- ============================================================
-- FUNÇÃO: Atualiza updated_at automaticamente
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_quotes_updated_at BEFORE UPDATE ON quotes
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================
-- Usuário admin padrão (senha: Admin@123456 — TROQUE IMEDIATAMENTE)
-- Hash bcrypt com 12 rounds para: Admin@123456
-- ============================================================
INSERT INTO users (id, name, email, password_hash, role, is_active, email_verified) VALUES (
  uuid_generate_v4(),
  'Administrador',
  'admin@marketplace.local',
  '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewPbpxVFQv8Ul.Hq',
  'admin',
  true,
  true
) ON CONFLICT (email) DO NOTHING;
