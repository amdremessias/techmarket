/**
 * test_api.js — Testa o endpoint GET /api/users após o fix
 * Primeiro faz login para obter o token, depois testa a listagem
 */
const { Client } = require('ssh2');

const conn = new Client();
conn.on('ready', () => {
  console.log('🔌 Conectado. Testando API...\n');

  // 1. Login para obter token
  const loginCmd = `curl -s -X POST http://localhost:4000/api/auth/login \
    -H "Content-Type: application/json" \
    -d '{"email":"admin@marketplace.local","password":"Admin@2024Secure!"}'`;

  conn.exec(loginCmd, (err, stream) => {
    if (err) throw err;
    let loginBody = '';
    stream.on('data', d => { loginBody += d.toString(); });
    stream.stderr.on('data', d => process.stderr.write(d.toString()));
    stream.on('close', () => {
      let token = '';
      try {
        const parsed = JSON.parse(loginBody);
        token = parsed.data?.accessToken || '';
        console.log('✅ Login OK. Role:', parsed.data?.user?.role);
        console.log('   Token:', token.substring(0, 30) + '...\n');
      } catch (e) {
        console.log('❌ Resposta do login:', loginBody);
        conn.end();
        return;
      }

      // 2. GET /api/users com o token
      const usersCmd = `curl -s -X GET http://localhost:4000/api/users \
        -H "Authorization: Bearer ${token}"`;

      conn.exec(usersCmd, (err2, stream2) => {
        if (err2) throw err2;
        let body = '';
        stream2.on('data', d => { body += d.toString(); });
        stream2.stderr.on('data', d => process.stderr.write(d.toString()));
        stream2.on('close', () => {
          try {
            const res = JSON.parse(body);
            if (res.success) {
              console.log(`✅ GET /api/users: OK — ${res.data.length} usuário(s) encontrado(s)`);
              res.data.forEach(u => console.log(`   • ${u.name} <${u.email}> [${u.role}] ativo=${u.is_active}`));
            } else {
              console.log('❌ Erro:', res.message);
              console.log('   Body:', body);
            }
          } catch (e) {
            console.log('❌ Resposta inválida:', body);
          }
          conn.end();
        });
      });
    });
  });
}).on('error', err => console.error('Erro de conexão:', err))
  .connect({ host: '192.168.5.67', port: 22, username: 'm3ss14s', password: '@mdreWp4ss' });
