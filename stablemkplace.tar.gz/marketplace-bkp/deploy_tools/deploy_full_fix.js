/**
 * deploy_full_fix.js
 * Deploy completo da correção:
 *  - Frontend: layout.js (menu corrigido), admin/users/page.js, admin/profile/page.js
 *  - Backend: users.controller.js (corrigido provider_services → provider_categories)
 * + reinicia ambos os containers
 */
const { Client } = require('ssh2');
const path = require('path');
const fs = require('fs');

const conn = new Client();
const serverConfig = {
  host: '192.168.5.67',
  port: 22,
  username: 'm3ss14s',
  password: '@mdreWp4ss',
};

const BASE_LOCAL  = path.join(__dirname, '..');
const BASE_REMOTE = '/home/m3ss14s/agente-cursor-marketplace';

const files = [
  // Backend
  {
    local:  path.join(BASE_LOCAL, 'backend/src/modules/users/users.controller.js'),
    remote: `${BASE_REMOTE}/backend/src/modules/users/users.controller.js`,
  },
  {
    local:  path.join(BASE_LOCAL, 'backend/src/modules/users/users.routes.js'),
    remote: `${BASE_REMOTE}/backend/src/modules/users/users.routes.js`,
  },
  // Frontend
  {
    local:  path.join(BASE_LOCAL, 'frontend/src/app/dashboard/layout.js'),
    remote: `${BASE_REMOTE}/frontend/src/app/dashboard/layout.js`,
  },
  {
    local:  path.join(BASE_LOCAL, 'frontend/src/app/admin/users/page.js'),
    remote: `${BASE_REMOTE}/frontend/src/app/admin/users/page.js`,
  },
  {
    local:  path.join(BASE_LOCAL, 'frontend/src/app/admin/profile/page.js'),
    remote: `${BASE_REMOTE}/frontend/src/app/admin/profile/page.js`,
  },
];

// Cria diretório remoto recursivamente (simplificado: tenta criar e ignora erro)
function ensureRemoteDir(sftp, remotePath, cb) {
  const parts = remotePath.split('/').filter(Boolean);
  let current = '';
  let i = 0;
  function next() {
    if (i >= parts.length) return cb();
    current += '/' + parts[i++];
    sftp.mkdir(current, () => next()); // ignora erro se já existe
  }
  next();
}

conn.on('ready', () => {
  console.log('🔌 Conectado ao servidor...\n');
  conn.sftp((err, sftp) => {
    if (err) throw err;

    let uploaded = 0;
    const uploadNext = (index) => {
      if (index >= files.length) {
        console.log(`\n✅ ${uploaded}/${files.length} arquivo(s) enviado(s). Reiniciando containers...\n`);
        return restartAll();
      }
      const { local, remote } = files[index];
      const remoteDir = remote.substring(0, remote.lastIndexOf('/'));
      ensureRemoteDir(sftp, remoteDir, () => {
        sftp.fastPut(local, remote, (putErr) => {
          if (putErr) {
            console.error(`❌ ERRO ao enviar ${path.basename(local)}: ${putErr.message}`);
          } else {
            uploaded++;
            console.log(`📤 [${uploaded}/${files.length}] ${path.basename(local)}`);
          }
          uploadNext(index + 1);
        });
      });
    };
    uploadNext(0);
  });
});

function exec(cmd, cb) {
  conn.exec(cmd, (err, stream) => {
    if (err) return cb(err);
    let out = '';
    stream.on('data', d => { out += d.toString(); process.stdout.write(d.toString()); });
    stream.stderr.on('data', d => process.stderr.write(d.toString()));
    stream.on('close', () => cb(null, out));
  });
}

function restartAll() {
  exec(`echo '@mdreWp4ss' | sudo -S docker restart marketplace_backend`, (err) => {
    if (err) throw err;
    console.log('\n⏳ Aguardando backend (4s)...');
    setTimeout(() => {
      exec(`echo '@mdreWp4ss' | sudo -S docker restart marketplace_frontend`, (err2) => {
        if (err2) throw err2;
        console.log('\n🚀 Tudo reiniciado com sucesso!');
        console.log('\n📋 Resumo das correções:');
        console.log('   • provider_services → provider_categories (tabela correta no banco)');
        console.log('   • provider_id → user_id (coluna correta)');
        console.log('   • COALESCE adicionado — listagem não quebra mais com erro 500');
        console.log('   • Menu admin: "Meu Perfil" aponta para /admin/profile');
        console.log('   • Página de criação de usuários com todos os campos');
        conn.end();
      });
    }, 4000);
  });
}

conn.on('error', err => console.error('Erro de conexão:', err));
conn.connect(serverConfig);
