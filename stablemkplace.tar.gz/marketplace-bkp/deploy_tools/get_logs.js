const { Client } = require('ssh2');

const conn = new Client();
const serverConfig = {
  host: '192.168.5.67',
  port: 22,
  username: 'm3ss14s',
  password: '@mdreWp4ss'
};

conn.on('ready', () => {
  console.log('Client :: ready');
  conn.exec("echo '@mdreWp4ss' | sudo -S docker logs --tail 100 marketplace_backend", (err, stream) => {
    if (err) throw err;
    stream.on('data', (data) => {
      process.stdout.write(data);
    }).on('close', () => {
      conn.end();
    });
  });
}).on('error', (err) => {
  console.error('Connection error:', err);
}).connect(serverConfig);
