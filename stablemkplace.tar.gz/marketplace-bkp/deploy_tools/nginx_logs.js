const { Client } = require('ssh2');

const conn = new Client();
const serverConfig = {
  host: '192.168.5.67',
  port: 22,
  username: 'm3ss14s',
  password: '@mdreWp4ss'
};

conn.on('ready', () => {
  console.log('Client :: ready');
  
  // Verifica logs do Nginx para ver se há erros de roteamento ou assets bloqueados
  const cmd = `echo '@mdreWp4ss' | sudo -S docker logs marketplace_nginx --tail 50`;
  
  conn.exec(cmd, (err, stream) => {
    if (err) throw err;
    stream.on('close', (code) => {
      conn.end();
    }).on('data', (data) => {
      process.stdout.write(data.toString());
    }).stderr.on('data', (data) => {
      process.stderr.write(data.toString());
    });
  });
}).on('error', (err) => {
  console.error('Connection error:', err);
}).connect(serverConfig);
