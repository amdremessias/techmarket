const { Client } = require('ssh2');

const conn = new Client();
const serverConfig = {
  host: '192.168.5.67',
  port: 22,
  username: 'm3ss14s',
  password: '@mdreWp4ss'
};

conn.on('ready', () => {
  console.log('Client :: ready');
  
  const sql = `
    -- Alterar padrão para novos usuários
    ALTER TABLE users ALTER COLUMN is_active SET DEFAULT false;
    
    -- Garantir que admins criados manualmente sejam ativos
    UPDATE users SET is_active = true WHERE role = 'admin';
  `;
  
  const cmd = `echo '@mdreWp4ss' | sudo -S docker exec -i marketplace_db psql -U marketplace_user -d marketplace -c "${sql}"`;
  
  conn.exec(cmd, (err, stream) => {
    if (err) throw err;
    stream.on('close', (code) => {
      console.log('Database updated for approval workflow with code ' + code);
      conn.end();
    });
  });
}).on('error', (err) => {
  console.error('Connection error:', err);
}).connect(serverConfig);
