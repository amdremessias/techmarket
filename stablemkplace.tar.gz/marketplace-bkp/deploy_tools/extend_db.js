const { Client } = require('ssh2');

const conn = new Client();
const serverConfig = {
  host: '192.168.5.67',
  port: 22,
  username: 'm3ss14s',
  password: '@mdreWp4ss'
};

conn.on('ready', () => {
  console.log('Client :: ready');
  
  // Passo 1: Adicionar o valor ao enum (não pode estar em transação com o UPDATE)
  const cmd1 = `echo '@mdreWp4ss' | sudo -S docker exec -i marketplace_db psql -U marketplace_user -d marketplace -c "ALTER TYPE subscription_plan ADD VALUE IF NOT EXISTS 'ENTERPRISE';"`;
  
  // Passo 2: Outras alterações e o UPDATE
  const sql2 = `
    ALTER TABLE users ADD COLUMN IF NOT EXISTS quote_limit INTEGER DEFAULT 3;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS monthly_quotes_count INTEGER DEFAULT 0;
    
    CREATE TABLE IF NOT EXISTS cities (
      id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
      name VARCHAR(100) NOT NULL,
      state VARCHAR(2) NOT NULL,
      is_active BOOLEAN NOT NULL DEFAULT true,
      created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
    );
    
    UPDATE users SET quote_limit = 3 WHERE plan = 'FREE';
    UPDATE users SET quote_limit = 15 WHERE plan = 'PREMIUM_PROVIDER';
    UPDATE users SET quote_limit = 999999 WHERE plan = 'ENTERPRISE';
  `;
  const cmd2 = `echo '@mdreWp4ss' | sudo -S docker exec -i marketplace_db psql -U marketplace_user -d marketplace -c "${sql2}"`;
  
  conn.exec(cmd1, (err, stream) => {
    if (err) throw err;
    stream.on('close', (code) => {
      conn.exec(cmd2, (err2, stream2) => {
        if (err2) throw err2;
        stream2.on('close', (code2) => {
          console.log('Database extended successfully');
          conn.end();
        }).on('data', (d) => process.stdout.write(d));
      });
    }).on('data', (d) => process.stdout.write(d));
  });
}).on('error', (err) => {
  console.error('Connection error:', err);
}).connect(serverConfig);
