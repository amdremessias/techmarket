const { Client } = require('ssh2');

const conn = new Client();
const serverConfig = {
  host: '192.168.5.67',
  port: 22,
  username: 'm3ss14s',
  password: '@mdreWp4ss'
};

conn.on('ready', () => {
  console.log('Client :: ready');
  
  // Testa a conectividade usando node
  const script = `require('http').get('http://backend:4000/api/health', (res) => { console.log('STATUS:', res.statusCode); res.on('data', d => process.stdout.write(d)); }).on('error', e => console.error(e));`;
  const cmd = `echo '@mdreWp4ss' | sudo -S docker exec marketplace_frontend node -e "${script}"`;
  
  conn.exec(cmd, (err, stream) => {
    if (err) throw err;
    stream.on('close', (code) => {
      conn.end();
    }).on('data', (data) => {
      process.stdout.write(data.toString());
    }).stderr.on('data', (data) => {
      process.stderr.write(data.toString());
    });
  });
}).on('error', (err) => {
  console.error('Connection error:', err);
}).connect(serverConfig);
