const { Client } = require('ssh2');

const conn = new Client();
conn.on('ready', () => {
  conn.exec('echo @mdreWp4ss | sudo -S docker exec marketplace_db psql -U marketplace_user -d marketplace_db -c "\\dt"', (err, stream) => {
    if (err) throw err;
    stream.on('data', d => process.stdout.write(d)).on('close', () => conn.end());
  });
}).connect({host:'192.168.5.67',port:22,username:'m3ss14s',password:'@mdreWp4ss'});
