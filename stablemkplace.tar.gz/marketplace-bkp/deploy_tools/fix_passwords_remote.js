const { Client } = require('ssh2');

const conn = new Client();
const serverConfig = {
  host: '192.168.5.67',
  port: 22,
  username: 'm3ss14s',
  password: '@mdreWp4ss'
};

conn.on('ready', () => {
  console.log('Client :: ready');
  
  // Script simplificado usando aspas duplas para evitar conflito com o shell
  const script = `
const bcrypt = require("bcryptjs");
const { Client } = require("pg");

const client = new Client({
  connectionString: "postgresql://marketplace_user:marketplace_pass@marketplace_db:5432/marketplace"
});

async function run() {
  await client.connect();
  const hash = await bcrypt.hash("Admin@1234", 12);
  console.log("Hash gerado.");
  await client.query("UPDATE users SET password_hash = $1", [hash]);
  console.log("Usuarios atualizados.");
  await client.end();
}
run().catch(console.error);
  `.replace(/\n/g, ' '); // Remove quebras de linha para o comando de uma linha
  
  const cmd = `echo "@mdreWp4ss" | sudo -S docker exec -i marketplace_backend node -e '${script}'`;
  
  conn.exec(cmd, (err, stream) => {
    if (err) throw err;
    stream.on('close', (code) => {
      console.log('Password fix script completed with code ' + code);
      conn.end();
    }).on('data', (data) => {
      process.stdout.write(data.toString());
    }).stderr.on('data', (data) => {
      process.stderr.write(data.toString());
    });
  });
}).on('error', (err) => {
  console.error('Connection error:', err);
}).connect(serverConfig);
