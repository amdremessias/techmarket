const { Client } = require('ssh2');
const path = require('path');

const conn = new Client();
const serverConfig = {
  host: '192.168.5.67',
  port: 22,
  username: 'm3ss14s',
  password: '@mdreWp4ss'
};

conn.on('ready', () => {
  console.log('Client :: ready');
  conn.sftp((err, sftp) => {
    if (err) throw err;
    
    const localInit = path.join(__dirname, '../database/init.sql');
    const remoteInit = '/home/m3ss14s/agente-cursor-marketplace/database/init.sql';
    
    sftp.fastPut(localInit, remoteInit, (err) => {
      if (err) throw err;
      console.log('init.sql uploaded');
      
      const cmd = `echo '@mdreWp4ss' | sudo -S sh -c 'docker exec -i marketplace_db psql -U marketplace_user -d marketplace < /home/m3ss14s/agente-cursor-marketplace/database/init.sql' && echo '@mdreWp4ss' | sudo -S sh -c 'docker exec -i marketplace_db psql -U marketplace_user -d marketplace < /home/m3ss14s/agente-cursor-marketplace/database/seed.sql'`;
      
      conn.exec(cmd, (err, stream) => {
        if (err) throw err;
        stream.on('close', (code) => {
          console.log('Database fix command completed with code ' + code);
          conn.end();
        }).on('data', (data) => {
          process.stdout.write(data.toString());
        }).stderr.on('data', (data) => {
          process.stderr.write(data.toString());
        });
      });
    });
  });
}).on('error', (err) => {
  console.error('Connection error:', err);
}).connect(serverConfig);
