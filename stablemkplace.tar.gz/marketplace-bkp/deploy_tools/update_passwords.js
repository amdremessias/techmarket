const bcrypt = require('bcryptjs');
const { Client } = require('ssh2');

const password = 'Client@123456';
const saltRounds = 12;

bcrypt.hash(password, saltRounds, (err, hash) => {
  if (err) throw err;
  console.log('New hash for Client@123456:', hash);
  
  const conn = new Client();
  const serverConfig = {
    host: '192.168.5.67',
    port: 22,
    username: 'm3ss14s',
    password: '@mdreWp4ss'
  };

  conn.on('ready', () => {
    const cmd = `echo '@mdreWp4ss' | sudo -S docker exec -i marketplace_db psql -U marketplace_user -d marketplace -c "UPDATE users SET password_hash = '${hash}';"`;
    
    conn.exec(cmd, (err, stream) => {
      if (err) throw err;
      stream.on('close', (code) => {
        console.log('Password update completed with code ' + code);
        conn.end();
      }).on('data', (data) => {
        process.stdout.write(data.toString());
      }).stderr.on('data', (data) => {
        process.stderr.write(data.toString());
      });
    });
  }).on('error', (err) => {
    console.error('Connection error:', err);
  }).connect(serverConfig);
});
