const { Client } = require('ssh2');

const conn = new Client();
const serverConfig = {
  host: '192.168.5.67',
  port: 22,
  username: 'm3ss14s',
  password: '@mdreWp4ss'
};

conn.on('ready', () => {
  console.log('Client :: ready');
  
  // Script para gerar o hash usando o bcrypt do próprio backend
  const script = `const b = require('bcryptjs'); b.hash('admin123', 12).then(console.log);`;
  const cmd = `echo '@mdreWp4ss' | sudo -S docker exec marketplace_backend node -e "${script}"`;
  
  conn.exec(cmd, (err, stream) => {
    if (err) throw err;
    stream.on('close', (code) => {
      conn.end();
    }).on('data', (data) => {
      const hash = data.toString().trim();
      if (hash.startsWith('$2')) {
        console.log('HASH_GENERATED:' + hash);
      } else {
        process.stdout.write(data.toString());
      }
    }).stderr.on('data', (data) => {
      process.stderr.write(data.toString());
    });
  });
}).on('error', (err) => {
  console.error('Connection error:', err);
}).connect(serverConfig);
