const { Client } = require('ssh2');

const conn = new Client();
const serverConfig = {
  host: '192.168.5.67',
  port: 22,
  username: 'm3ss14s',
  password: '@mdreWp4ss'
};

conn.on('ready', () => {
  console.log('Client :: ready');
  
  const hash = '\\$2a\\$12\\$ZOAD0PRCwtFWX7pzze6KWO3AxftDwOuXCYS5TYWzxdqGOxytH.xMG';
  
  const cmd = `echo '@mdreWp4ss' | sudo -S docker exec -i marketplace_db psql -U marketplace_user -d marketplace -c "UPDATE users SET password_hash = '${hash}' WHERE email = 'tecnico@demo.local';"`;
  
  conn.exec(cmd, (err, stream) => {
    if (err) throw err;
    stream.on('close', (code) => {
      conn.end();
    });
  });
}).on('error', (err) => {
  console.error('Connection error:', err);
}).connect(serverConfig);
