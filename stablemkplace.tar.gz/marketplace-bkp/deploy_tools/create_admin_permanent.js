/**
 * create_admin_permanent.js
 * Cria/atualiza o admin permanente no banco de dados do servidor.
 * O hash é gerado DENTRO do container backend (garante bcryptjs compatível).
 *
 * Credenciais do admin criado:
 *   email: admin@marketplace.local
 *   senha: Admin@2024Secure!
 */
const { Client } = require('ssh2');

const conn = new Client();
const serverConfig = {
  host: '192.168.5.67',
  port: 22,
  username: 'm3ss14s',
  password: '@mdreWp4ss'
};

const ADMIN_PASSWORD = 'Admin@2024Secure!';
const ADMIN_NAME     = 'Administrador';
const ADMIN_EMAIL    = 'admin@marketplace.local';

conn.on('ready', () => {
  console.log('🔌 Conectado ao servidor...');

  // Etapa 1: gera o hash bcrypt com 12 rounds dentro do backend
  const hashScript = `const b=require('bcryptjs');b.hash('${ADMIN_PASSWORD}',12).then(h=>process.stdout.write(h));`;
  const hashCmd = `echo '@mdreWp4ss' | sudo -S docker exec marketplace_backend node -e "${hashScript}"`;

  conn.exec(hashCmd, (err, stream) => {
    if (err) throw err;

    let hash = '';
    stream.on('data', d => { hash += d.toString(); });
    stream.stderr.on('data', d => process.stderr.write(d.toString()));

    stream.on('close', () => {
      hash = hash.trim();
      if (!hash.startsWith('$2')) {
        console.error('❌ Falha ao gerar hash. Saída:', hash);
        conn.end();
        return;
      }

      console.log('🔑 Hash gerado com sucesso.');

      // Etapa 2: insere ou atualiza o admin no banco
      const sql = `
        INSERT INTO users (id, name, email, password_hash, role, is_active, email_verified)
        VALUES (uuid_generate_v4(), '${ADMIN_NAME}', '${ADMIN_EMAIL}', '${hash}', 'admin', true, true)
        ON CONFLICT (email) DO UPDATE
          SET name          = EXCLUDED.name,
              password_hash = EXCLUDED.password_hash,
              role          = 'admin',
              is_active     = true,
              email_verified= true,
              updated_at    = NOW();
      `.replace(/\n/g, ' ').replace(/'/g, "'\\''");

      const psqlCmd = `echo '@mdreWp4ss' | sudo -S docker exec marketplace_db psql -U marketplace_user -d marketplace -c '${sql}'`;

      conn.exec(psqlCmd, (err2, stream2) => {
        if (err2) throw err2;

        stream2.on('data', d => process.stdout.write(d.toString()));
        stream2.stderr.on('data', d => process.stderr.write(d.toString()));
        stream2.on('close', () => {
          console.log('\n✅ Admin criado/atualizado com sucesso!');
          console.log(`   Email : ${ADMIN_EMAIL}`);
          console.log(`   Senha : ${ADMIN_PASSWORD}`);
          conn.end();
        });
      });
    });
  });
}).on('error', err => {
  console.error('Erro de conexão:', err);
}).connect(serverConfig);
