const { Client } = require('ssh2');
const fs = require('fs');
const path = require('path');

const conn = new Client();
const serverConfig = {
  host: '192.168.5.67',
  port: 22,
  username: 'm3ss14s',
  password: '@mdreWp4ss'
};

const localTarball = path.join(__dirname, '..', 'deploy.tar.gz');
const remoteDir = '/home/m3ss14s/agente-cursor-marketplace';
const remoteTarball = `${remoteDir}/deploy.tar.gz`;

console.log('Starting deployment to 192.168.5.67...');

conn.on('ready', () => {
  console.log('Client :: ready');
  
  // Step 1: Create Remote Directory
  conn.exec(`mkdir -p ${remoteDir}`, (err, stream) => {
    if (err) throw err;
    stream.on('data', (data) => console.log('mkdir stdout:', data.toString()));
    stream.stderr.on('data', (data) => console.log('mkdir stderr:', data.toString()));
    stream.on('close', (code, signal) => {
      console.log('Directory created.');
      
      // Step 2: Upload File
      conn.sftp((err, sftp) => {
        if (err) throw err;
        console.log('Uploading deploy.tar.gz...');
        
        sftp.fastPut(localTarball, remoteTarball, (err) => {
          if (err) throw err;
          console.log('Upload complete.');
          
          // Step 3: Extract and start Docker Compose
          const deployCommand = `
            cd ${remoteDir} &&
            tar -xzvf deploy.tar.gz &&
            sed -i 's/npm ci/npm install/g' frontend/Dockerfile backend/Dockerfile &&
            if [ ! -f .env ]; then cp .env.example .env; fi &&
            if [ ! -f frontend/.env ]; then cp frontend/.env.example frontend/.env; fi &&
            if [ ! -f backend/.env ]; then cp .env backend/.env; fi &&
            echo '@mdreWp4ss' | sudo -S docker compose down || true &&
            echo '@mdreWp4ss' | sudo -S docker compose up -d --build
          `;
          
          console.log('Running deployment commands...');
          conn.exec(deployCommand, (err, stream) => {
            if (err) throw err;
            stream.on('close', (code, signal) => {
              console.log('Deployment commands executed with code ' + code);
              conn.end();
            }).on('data', (data) => {
              process.stdout.write(data.toString());
            }).stderr.on('data', (data) => {
              process.stderr.write(data.toString());
            });
          });
        });
      });
    });
  });
}).on('error', (err) => {
  console.error('Connection error:', err);
}).connect(serverConfig);
