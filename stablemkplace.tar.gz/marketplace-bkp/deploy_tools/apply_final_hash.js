const { Client } = require('ssh2');

const conn = new Client();
const serverConfig = {
  host: '192.168.5.67',
  port: 22,
  username: 'm3ss14s',
  password: '@mdreWp4ss'
};

conn.on('ready', () => {
  console.log('Client :: ready');
  
  // Hash correto: $2a$12$ZOAD0PRCwtFWX7pzze6KWO3AxftDwOuXCYS5TYWzxdqGOxytH.xMG
  // Escapando o $ para o bash
  const hash = '\\$2a\\$12\\$ZOAD0PRCwtFWX7pzze6KWO3AxftDwOuXCYS5TYWzxdqGOxytH.xMG';
  
  const cmd = `echo '@mdreWp4ss' | sudo -S docker exec -i marketplace_db psql -U marketplace_user -d marketplace -c "UPDATE users SET password_hash = '${hash}' WHERE email = 'admin@marketplace.local';"`;
  
  conn.exec(cmd, (err, stream) => {
    if (err) throw err;
    stream.on('close', (code) => {
      console.log('Final Admin password reset completed with code ' + code);
      conn.end();
    }).on('data', (data) => {
      process.stdout.write(data.toString());
    }).stderr.on('data', (data) => {
      process.stderr.write(data.toString());
    });
  });
}).on('error', (err) => {
  console.error('Connection error:', err);
}).connect(serverConfig);
