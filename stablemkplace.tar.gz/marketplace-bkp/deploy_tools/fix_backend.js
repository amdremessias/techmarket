const { Client } = require('ssh2');
const path = require('path');
const fs = require('fs');

const conn = new Client();
const serverConfig = {
  host: '192.168.5.67',
  port: 22,
  username: 'm3ss14s',
  password: '@mdreWp4ss'
};

function uploadDir(sftp, localPath, remotePath, callback) {
  sftp.mkdir(remotePath, (err) => {
    const files = fs.readdirSync(localPath);
    let count = 0;
    if (files.length === 0) return callback();

    files.forEach(file => {
      const fullLocal = path.join(localPath, file);
      const fullRemote = remotePath + '/' + file;
      const stats = fs.statSync(fullLocal);

      if (stats.isDirectory()) {
        uploadDir(sftp, fullLocal, fullRemote, () => {
          count++;
          if (count === files.length) callback();
        });
      } else {
        sftp.fastPut(fullLocal, fullRemote, (err) => {
          if (err) throw err;
          count++;
          if (count === files.length) callback();
        });
      }
    });
  });
}

conn.on('ready', () => {
  console.log('Client :: ready');
  conn.sftp((err, sftp) => {
    if (err) throw err;
    
    // Upload users module
    const localUsers = path.join(__dirname, '../backend/src/modules/users');
    const remoteUsers = '/home/m3ss14s/agente-cursor-marketplace/backend/src/modules/users';
    
    // Upload cities module
    const localCities = path.join(__dirname, '../backend/src/modules/cities');
    const remoteCities = '/home/m3ss14s/agente-cursor-marketplace/backend/src/modules/cities';

    // Upload app.js
    const localApp = path.join(__dirname, '../backend/src/app.js');
    const remoteApp = '/home/m3ss14s/agente-cursor-marketplace/backend/src/app.js';

    uploadDir(sftp, localUsers, remoteUsers, () => {
      console.log('Backend Users module uploaded');
      uploadDir(sftp, localCities, remoteCities, () => {
        console.log('Backend Cities module uploaded');
        sftp.fastPut(localApp, remoteApp, (err) => {
          if (err) throw err;
          console.log('app.js updated');
          
          // Upload quotes controller updated earlier
          const localQuotes = path.join(__dirname, '../backend/src/modules/quotes/quotes.controller.js');
          const remoteQuotes = '/home/m3ss14s/agente-cursor-marketplace/backend/src/modules/quotes/quotes.controller.js';
          
          // Upload services routes updated
          const localServicesRoutes = path.join(__dirname, '../backend/src/modules/services/services.routes.js');
          const remoteServicesRoutes = '/home/m3ss14s/agente-cursor-marketplace/backend/src/modules/services/services.routes.js';
          
          sftp.fastPut(localServicesRoutes, remoteServicesRoutes, (err) => {
            if (err) throw err;
            console.log('Services routes updated');
            conn.end();
          });
        });
      });
    });
  });
}).on('error', (err) => {
  console.error('Connection error:', err);
}).connect(serverConfig);
