/**
 * deploy_password_feature.js
 * Sobe para o servidor os arquivos do recurso de gerenciamento de senhas:
 *   - backend/src/modules/users/users.controller.js (endpoints changePassword + changeOwnPassword)
 *   - backend/src/modules/users/users.routes.js (rotas PATCH /:id/password e /me/password)
 *   - frontend/src/app/admin/users/page.js (modal de troca de senha)
 *   - frontend/src/app/admin/profile/page.js (perfil + troca da própria senha)
 * e reinicia os containers backend e frontend.
 */
const { Client } = require('ssh2');
const path = require('path');

const conn = new Client();
const serverConfig = {
  host: '192.168.5.67',
  port: 22,
  username: 'm3ss14s',
  password: '@mdreWp4ss',
};

const BASE_LOCAL  = path.join(__dirname, '..');
const BASE_REMOTE = '/home/m3ss14s/agente-cursor-marketplace';

const files = [
  {
    local:  path.join(BASE_LOCAL, 'backend/src/modules/users/users.controller.js'),
    remote: `${BASE_REMOTE}/backend/src/modules/users/users.controller.js`,
  },
  {
    local:  path.join(BASE_LOCAL, 'backend/src/modules/users/users.routes.js'),
    remote: `${BASE_REMOTE}/backend/src/modules/users/users.routes.js`,
  },
  {
    local:  path.join(BASE_LOCAL, 'frontend/src/app/admin/users/page.js'),
    remote: `${BASE_REMOTE}/frontend/src/app/admin/users/page.js`,
  },
  {
    local:  path.join(BASE_LOCAL, 'frontend/src/app/admin/profile/page.js'),
    remote: `${BASE_REMOTE}/frontend/src/app/admin/profile/page.js`,
  },
];

conn.on('ready', () => {
  console.log('🔌 Conectado ao servidor...');
  conn.sftp((err, sftp) => {
    if (err) throw err;

    let uploaded = 0;

    const uploadNext = (index) => {
      if (index >= files.length) {
        console.log('\n✅ Todos os arquivos enviados. Reiniciando containers...');
        restartContainers();
        return;
      }
      const { local, remote } = files[index];
      // Garante que o diretório remoto existe (mkdirp manual via mkdir)
      const remoteDir = remote.substring(0, remote.lastIndexOf('/'));
      sftp.mkdir(remoteDir, () => {                    // ignora erro se já existe
        sftp.fastPut(local, remote, (putErr) => {
          if (putErr) {
            console.error(`❌ Falha ao enviar ${path.basename(local)}:`, putErr.message);
          } else {
            uploaded++;
            console.log(`📤 [${uploaded}/${files.length}] ${path.basename(local)}`);
          }
          uploadNext(index + 1);
        });
      });
    };

    uploadNext(0);
  });
});

function restartContainers() {
  const cmd = `echo '@mdreWp4ss' | sudo -S docker restart marketplace_backend marketplace_frontend`;
  conn.exec(cmd, (err, stream) => {
    if (err) throw err;
    stream.on('data', d => process.stdout.write(d.toString()));
    stream.stderr.on('data', d => process.stderr.write(d.toString()));
    stream.on('close', () => {
      console.log('\n🚀 Containers reiniciados com sucesso!');
      conn.end();
    });
  });
}

conn.on('error', err => console.error('Erro de conexão:', err));
conn.connect(serverConfig);
