const { Client } = require('ssh2');
const path = require('path');
const fs = require('fs');

const conn = new Client();
const serverConfig = {
  host: '192.168.5.67',
  port: 22,
  username: 'm3ss14s',
  password: '@mdreWp4ss'
};

function uploadDir(sftp, localPath, remotePath, callback) {
  sftp.mkdir(remotePath, (err) => {
    // Ignore error if directory already exists
    const files = fs.readdirSync(localPath);
    let count = 0;
    if (files.length === 0) return callback();

    files.forEach(file => {
      const fullLocal = path.join(localPath, file);
      const fullRemote = remotePath + '/' + file;
      const stats = fs.statSync(fullLocal);

      if (stats.isDirectory()) {
        uploadDir(sftp, fullLocal, fullRemote, () => {
          count++;
          if (count === files.length) callback();
        });
      } else {
        sftp.fastPut(fullLocal, fullRemote, (err) => {
          if (err) throw err;
          count++;
          if (count === files.length) callback();
        });
      }
    });
  });
}

conn.on('ready', () => {
  console.log('Client :: ready');
  conn.sftp((err, sftp) => {
    if (err) throw err;
    
    // Upload Dashboard folder
    const localDashboard = path.join(__dirname, '../frontend/src/app/dashboard');
    const remoteDashboard = '/home/m3ss14s/agente-cursor-marketplace/frontend/src/app/dashboard';
    
    // Upload Admin folder
    const localAdmin = path.join(__dirname, '../frontend/src/app/admin');
    const remoteAdmin = '/home/m3ss14s/agente-cursor-marketplace/frontend/src/app/admin';

    // Upload Lib folder
    const localLib = path.join(__dirname, '../frontend/src/lib');
    const remoteLib = '/home/m3ss14s/agente-cursor-marketplace/frontend/src/lib';
    
    uploadDir(sftp, localDashboard, remoteDashboard, () => {
      console.log('Dashboard folder uploaded');
      uploadDir(sftp, localAdmin, remoteAdmin, () => {
        console.log('Admin folder uploaded');
        uploadDir(sftp, localLib, remoteLib, () => {
          console.log('Lib folder uploaded');
          conn.end();
        });
      });
    });
  });
}).on('error', (err) => {
  console.error('Connection error:', err);
}).connect(serverConfig);
