/**
 * fix_provider_services.js
 * Corrige o erro "relation provider_services does not exist":
 *   1. Sobe o users.controller.js corrigido para o servidor
 *   2. Reinicia o container backend
 *   3. Verifica os logs para confirmar que o erro foi resolvido
 */
const { Client } = require('ssh2');
const path = require('path');

const conn = new Client();
const serverConfig = {
  host: '192.168.5.67',
  port: 22,
  username: 'm3ss14s',
  password: '@mdreWp4ss',
};

const LOCAL  = path.join(__dirname, '../backend/src/modules/users/users.controller.js');
const REMOTE = '/home/m3ss14s/agente-cursor-marketplace/backend/src/modules/users/users.controller.js';

conn.on('ready', () => {
  console.log('🔌 Conectado...');
  conn.sftp((err, sftp) => {
    if (err) throw err;

    sftp.fastPut(LOCAL, REMOTE, (putErr) => {
      if (putErr) throw putErr;
      console.log('📤 users.controller.js enviado com sucesso');

      // Reinicia o backend
      const restartCmd = `echo '@mdreWp4ss' | sudo -S docker restart marketplace_backend`;
      conn.exec(restartCmd, (err2, stream) => {
        if (err2) throw err2;
        stream.on('data', d => process.stdout.write(d.toString()));
        stream.stderr.on('data', d => process.stderr.write(d.toString()));
        stream.on('close', () => {
          console.log('\n⏳ Aguardando backend reiniciar (5s)...');
          setTimeout(() => {
            // Pega os últimos logs para confirmar
            const logsCmd = `echo '@mdreWp4ss' | sudo -S docker logs marketplace_backend --tail 15`;
            conn.exec(logsCmd, (err3, stream3) => {
              if (err3) throw err3;
              stream3.on('data', d => process.stdout.write(d.toString()));
              stream3.stderr.on('data', d => process.stderr.write(d.toString()));
              stream3.on('close', () => {
                console.log('\n✅ Deploy concluído!');
                conn.end();
              });
            });
          }, 5000);
        });
      });
    });
  });
});

conn.on('error', err => console.error('Erro de conexão:', err));
conn.connect(serverConfig);
